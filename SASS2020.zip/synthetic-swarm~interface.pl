%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File synthetic-swarm~interface.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% little predicates and peaces of majick that make it work!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% updated from swarmdemo.pl to work with synthetic-graphics.pl
% dnd
% 27 april 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% updated from synthetic-swarm~single.pl
% 05 05 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These predicates determine the processes and actions of single agent
% Loaded by swarmdemo.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code originally to enable prolog to connect and manage TCP/IP
% sockets to swarm robots 30/01/2014 onwards This version for the
% swarmII-pi3 combination Need to use this library for TCP/IP interfaces
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rather than use
%  ActivityBots (swarmBots)
%  Pioneer P3DX~CogBot as Host
%  AmigoBots as independent activity
% simulator to be used
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start of code to simulate "connection" to robot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% note possible supported modes <incomplete>
% cncmode(cognoncog, simulator).
% mode(cognoncog, swarmbots).
% mode(cognoncog, camal).
% mode(cognoncog, scarab).
% mode(cognoncog, aria).
% mode(cognoncog, amigobots).
% mode(cognoncog, p3dx).
% mode(cognoncog, colony).
%!	%%%%%%%
% Default:-
% cncmode(cognoncog, simulator).
% % calltoagent(Host, [Pred | Args ])
calltoagent( Host, exit ):-
	cncmode( cognoncog, simulator ), !,
	robot_swarm(Id, Host, _RobotList),
	disconnect_swarm(Id),
	% not send_to_bot(Host, exit),
	tidysimgraphics,
	!.
calltoagent( Host, exit ):-
	cncmode( cognoncog, swarmbots ), !,
	send_to_bot(Host, exit),
	!.
% exceptions for incomplete
calltoagent( Host, exit ):-
	cncmode( Project, Mode ), !,
	% send_to_bot(Host, exit),
	write('\t\t>> Unknown configuration : '), write( Host ), write(' '), write(Project), write(' '), writeln(Mode),
	!.
calltoagent(Host, [Pred | Args ]):-
	Host = Host, % writeln output now commented
	cncmode( cognoncog, simulator ), !,
	%write('\t\t>>> '),write(Host), write(' Supported call to agent '),
	%write( cognoncog ), write(' '), writeln( simulator ),
	%write('\t\t\t>>> with '),
	%write(Pred), write(' '), writeln(Args),
	% should be standard calls
	Clause =.. [simcall , Pred|Args], !,
	Clause,
	!.
calltoagent(Host, [Pred | Args ]):-
	cncmode( cognoncog, swarmbots ), !,
	write('\t\t>>> '),write(Host), write(' Supported call to agent '),
	write( cognoncog ), write(' '), writeln( swarmbots ),
	write('\t\t\t>>> with '),
	write(Pred), write(' '), writeln(Args),
	% should be standard calls
	Clause =.. [Pred|Args], !,
	Clause,
	!.
calltoagent(Host, [Pred | Args ]):-
	cncmode( Mode, TESTBED ),
	write('\t\t>>> '),write(Host), write(' Unrecognisable call to agent '),
	write(Mode), write(' '), writeln(TESTBED),
	write('\t\t\t>>> with '),
	write(Pred), write(' '), writeln(Args),
	!.

% variation on above :
%  but build the call to run the behaviour
% calltoagent/3
% calltoagent( Host, Member, MBehave )
calltoagent( Host, Member, MBehave ):-
	Predicate = [call_robot, Member, MBehave ],
	calltoagent( Host, Predicate ),
	!.

%! %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simcall/3 is one that calls agent to run as Robot with Behave
simcall(Predicate, Robot, Behave):-
	sim_robot_mapping( SwarmId, SwarmAgent, Robot ),
	PredicateArg = [SwarmId, SwarmAgent, [simcall, Predicate, Robot, Behave ] ],
	write('\t> '), writeln( PredicateArg ),
	% just add behaviours and then this
	call_robot(Robot, Behave),
	!.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% connection stuff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% use as connection(ROBOT, Socket, Read, Write).
:-dynamic(connection/4).
% extra stuff to mimic_connection to physical agents
/* for example
% sim_tcp_socket/1
	tcp_socket(Socket),
% tcp_connect/4
	tcp_connect(Socket, Address:Port, Read, Write), !,
% sim_tcp_close_socket/1
	tcp_close_socket( Socket),
 */
% sim_tcp_socket/1
:- dynamic( sim_tcp_socket/1).
% tcp_connect/4
:- dynamic( sim_tcp_connect/4).
% sim_tcp_close_socket/1
:- dynamic( sim_tcp_close_socket/1 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
connect_swarm( Id ):-
	robot_swarm(Id, Host, RobotList),
	sort( [Host | RobotList], Robots),
	connect_robot_swarm( Robots ).
connect_robot_swarm( [] ):- !.
connect_robot_swarm( [null|Swarm]):-
	!,
	connect_robot_swarm( Swarm ).
connect_robot_swarm([Robot|Swarm]):-
	robot_connect( Robot, S, R, W),
	assert( connection(Robot, S, R, W) ), !,
	connect_robot_swarm( Swarm ).

disconnect_swarm(Id):-
	robot_swarm(Id, Host, RobotList),
	sort( [Host | RobotList], Robots),
	disconnect_robot_swarm( Robots ),
	!.
disconnect_robot_swarm( [] ):- !.
disconnect_robot_swarm( [null|Robots] ):-
	!,
	disconnect_robot_swarm( Robots ).
disconnect_robot_swarm( [Robot|Robots] ):-
	send_to_bot(Robot, 48), !,
	disconnect_robot_swarm( Robots ).

robot_connect(Robot, Socket, Read, Write):-
	robot_id(Robot, Address, Port),
	sim_tcp_socket(Socket),
	sim_tcp_connect(Socket, Address:Port, Read, Write), !,
	clear_connect_buffer(Robot, Read, 7),
	!.
robot_connect(Robot, _Socket, _Read, _Write):-
	!,
	write('Failed to connect: '), writeln(Robot).

clear_connect_buffer(Robot, _Read, 0):-
	write(Robot), writeln('  connected'),
	!.
clear_connect_buffer(Robot, Read, N):-
	get_byte(Read, Message2),
	write('Robot sent: '), writeln(Message2),
	M is N-1,
	clear_connect_buffer(Robot, Read, M).


disconnect(null):-
	!.
disconnect(Socket):-
	sim_tcp_close_socket( Socket), !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% end of code to simulate "connection" to robot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensory Stuff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Specification for sensor simulation
%  sensor/4
%  sensor(Sensor, Range, Pattern, Arc).
%  Range is in Simulator units
%  sided sensors arc one way left or right of agent
%  other sensors arc about centre line +/- given Arc
%  ir2block, picamera, sonar, sonar_left, sonar_right
%  or unknown!
sensor(sonar, 150, arc, 25).
sensor(sonar_left, 150, arc, 25).
sensor(sonar_right, 150, arc, 25).
sensor(ir, 100, arc, 10).
sensor(ir2block, 100, arc, 15).
sensor(picamera, 150, arc, 25).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generic simulation of sensor
euclid(X1,Y1,X2,Y2,D):-
	D is sqrt( (Y2-Y1)*(Y2-Y1) +
		    (X2-X1)*(X2-X1) ),
	!.

% What is located in bounding box <current geometry incorrect>
% agent(SwarmAgent, XLoc, YLoc, _Size)
within_bounding_box(XMin, YMin, XMax, YMax, [SwarmAgent|Sensed]):-
	agent(SwarmAgent, XLoc, YLoc, Size),
	XLoc > XMin, XLoc < XMax,
	YLoc > YMin, YLoc < YMax, !,
	retract( agent(SwarmAgent, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( agent(SwarmAgent, XLoc, YLoc, Size) ),
	!.
within_bounding_box(XMin, YMin, XMax, YMax, Sensed):-
	agent(SwarmAgent, XLoc, YLoc, Size), !,
	retract( agent(SwarmAgent, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( agent(SwarmAgent, XLoc, YLoc, Size) ),
	!.
% source(C, X, Y, D)
within_bounding_box(XMin, YMin, XMax, YMax, [source-Circ|Sensed]):-
	source(Circ, XLoc, YLoc, Size),
	XLoc > XMin, XLoc < XMax,
	YLoc > YMin, YLoc < YMax, !,
	retract( source(Circ, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( source(Circ, XLoc, YLoc, Size) ),
	!.
within_bounding_box(XMin, YMin, XMax, YMax, Sensed):-
	source(Circ, XLoc, YLoc, Size), !,
	retract( source(Circ, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( source(Circ, XLoc, YLoc, Size) ),
	!.
% esource(C, X, Y, D)
within_bounding_box(XMin, YMin, XMax, YMax, [esource-Circ|Sensed]):-
	esource(Circ, XLoc, YLoc, Size),
	XLoc > XMin, XLoc < XMax,
	YLoc > YMin, YLoc < YMax, !,
	retract( esource(Circ, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( esource(Circ, XLoc, YLoc, Size) ),
	!.
within_bounding_box(XMin, YMin, XMax, YMax, Sensed):-
	esource(Circ, XLoc, YLoc, Size),
	retract( esource(Circ, XLoc, YLoc, Size) ),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	assert( esource(Circ, XLoc, YLoc, Size) ),
	!.
% Nothing else
within_bounding_box(_XMin,_YMin, _XMax, _YMax, []):-
	!.

agent_bounding_box(Agent, Range, [XMin, YMin, XMax, YMax]):-
	agent(Agent, XLoc, YLoc, _Size),
	agent_atts(Agent, _VarB, _VarC, Velx, Vely, _VarF),
	XMin is XLoc,
	YMin is YLoc,
	XMax is Velx+XLoc+Range,
	YMax is Vely+YLoc+Range,
	!.

distance_constraint(Distance, Range, Return, Return):-
	Distance < Range, !.
distance_constraint(Distance, Range, [OneThing|Return], Return):-
	Distance = Distance,
	Range = Range,
	OneThing = OneThing, !.
distance_constraint(Distance, Range, [One-Two|Return], Return):-
	Distance = Distance,
	Range = Range,
	One = One,
	Two = Two,
	!.

% Range only sense_within_range/3
sense_within_range(Agent, Range, Return):-
	agent(Agent, XALoc, YALoc, _ASize),
	esource(Circ, XSLoc, YSLoc, SSize),
	euclid(XSLoc,YSLoc,XALoc,YALoc,Distance),
	retract( esource(Circ, XSLoc, YSLoc, SSize) ),
	sense_within_range(Agent, Range, Sensed),
	assert( esource(Circ, XSLoc, YSLoc, SSize) ),
	distance_constraint(Distance, Range, [esource-Circ|Sensed], Return),
	!.
sense_within_range(Agent, Range, Return):-
	agent(Agent, XALoc, YALoc, _ASize),
	source(Circ, XSLoc, YSLoc, SSize),
	euclid(XSLoc,YSLoc,XALoc,YALoc,Distance),
	retract( source(Circ, XSLoc, YSLoc, SSize) ),
	sense_within_range(Agent, Range, Sensed),
	assert( source(Circ, XSLoc, YSLoc, SSize) ),
	distance_constraint(Distance, Range, [source-Circ|Sensed], Return),
	!.
sense_within_range(Agent, Range, Return):-
	agent(Agent, XALoc, YALoc, _ASize),
	agent(SwarmAgent, XLoc, YLoc, Size),
	not( SwarmAgent = Agent ),
	euclid(XLoc,YLoc,XALoc,YALoc,Distance),
	retract( agent(SwarmAgent, XLoc, YLoc, Size) ),
	sense_within_range(Agent, Range, Sensed),
	assert( agent(SwarmAgent, XLoc, YLoc, Size) ),
	distance_constraint(Distance, Range, [SwarmAgent|Sensed], Return),
	!.
sense_within_range(Agent, Range, []):-
	Range =	Range,
	Agent = Agent,
	!.
% Generic sense_within_range/5
sense_within_range(Agent, Range, Pattern, Arc, Sensed):-
	present_swarm_sensing( cognoncog, simulator, range),
	%agent(SwarmAgent, XLoc, YLoc, _Size),
	%agent_atts(SwarmAgent, _VarB, _VarC, Velx, Vely, _VarF),
	%XMax is Velx+XLoc+Range,
	%YMax is Vely+YLoc+Range,
	% use generic code
	Arc = Arc, % add that sophistication later
	Pattern = Pattern,
	sense_within_range(Agent, Range, Sensed),
	!.
sense_within_range(Agent, Range, Pattern, Arc, Sensed):-
	present_swarm_sensing( cognoncog, simulator, boundingbox),
	%agent(SwarmAgent, XLoc, YLoc, _Size),
	%agent_atts(SwarmAgent, _VarB, _VarC, Velx, Vely, _VarF),
	%XMax is Velx+XLoc+Range,
	%YMax is Vely+YLoc+Range,
	% use generic code
	Arc = Arc, % add that sophistication later
	Pattern = Pattern,
	agent_bounding_box(Agent, Range, [XMin, YMin, XMax, YMax]),
	within_bounding_box(XMin, YMin, XMax, YMax, Sensed),
	!.

% Known Sensor Arrays
% sonar, ir2block, picamera, sonar, sonar_left, sonar_right
sensory_data(Agent, sonar, Sensed):-
	%present_swarm_sensing( cognoncog, simulator, boundingbox),
	Sensor = sonar,
	sensor(Sensor, Range, Pattern, Arc),
	sense_within_range(Agent, Range, Pattern, Arc, Sensed),
	%write('\t> '), writeln(sensory_data(Agent, sonar, Sensed)),
	!.
/*
sensory_data(Agent, sonar, Sensed):-
	present_swarm_sensing( cognoncog, simulator, range),
	Sensor = sonar,
	sensor(Sensor, Range, Pattern, Arc),
	Pattern = Pattern, Arc = Arc, % use later
	sense_within_range(Agent, Range, _Pattern, _Arc, Sensed),
	write('\t> '), writeln(sensory_data(Agent, sonar, Sensed)),
	!.
*/
sensory_data(Agent, Sense, Return):-
	Agent = Agent,
	Sense = Sense,
	Return = [],
	%write('\t> '), writeln(sensory_data(Agent, Sense, Return)),
	!.

agent_sensory_data(Agent, Return ):-
	sim_robot_mapping( _SwarmId, Agent, Robot ),
	robot_config(Robot, _Pi, Sensors),
	agent_sensory_data(Agent, Sensors, Return),
	!.

agent_sensory_data(_Agent, [], []):-
	!.

agent_sensory_data(Agent, [Sensor|Sensors], [Sensor-Sensed|Return]):-
	sensory_data(Agent, Sensor, Sensed),
	agent_sensory_data(Agent, Sensors, Return),
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new range 48==0
% hardwired to 35 - should be parameter from architecture
call_robot(Robot, set_obstacle_range):-
	send_to_bot(Robot, 97),
	range is 48+35, !,
	send_to_bot(Robot, range), !.
% sonar value
call_robot(Robot, sonar_sensor):-
	send_to_bot(Robot, 98), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot sensor returns: '), writeln(Bool), !.
% is obstacle via sonar
call_robot(Robot, sonar_obstacle):-
	send_to_bot(Robot, 99), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot sensor returns: '), writeln(Bool), !.
% is obstacle via IR
call_robot(Robot, ir_obstacle):-
	send_to_bot(Robot, 100), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot IR sensor returns: '), writeln(Bool), !.
% is obstacle via PING and IR
call_robot(Robot, sonar_ir_obstacle):-
	send_to_bot(Robot, 101), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot PING AND IR sensor returns: '), writeln(Bool), !.
% hardwired to 25 - should be parameter from architecture
call_robot(Robot, set_ir_block_range):-
	send_to_bot(Robot, 102),
	range is 48+25, !,
	send_to_bot(Robot, range), !.
% is obstacle via 1 BLOCK IR
call_robot(Robot, ir_block_obstacle):-
	send_to_bot(Robot, 103), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot Block IR sensor returns: '), writeln(Bool), !.
% is obstacle via PING and 1 BLOCK IR
call_robot(Robot, sonar_ir_block_obstacle):-
	send_to_bot(Robot, 104), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot PING AND IR Block sensor returns: '), writeln(Bool), !.
% is obstacle via TWO BLOCK IR
call_robot(Robot, ir_2block_obstacle):-
	send_to_bot(Robot, 105), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot 2 Block IR sensor returns: '), writeln(Bool), !.
% is obstacle via PING and TWO BLOCK IR
call_robot(Robot, sonar_ir_2block_obstacle):-
	send_to_bot(Robot, 106), !,
	send_from_bot(Robot, Message),
	put_byte(Message),
	Bool is Message-48, !,
	write('Robot PING AND 2 IR Block sensor returns: '), writeln(Bool), !.

% these behaviours are calls to pi capabilities not propellor board
call_robot(_Robot, take_pi_image):-
	shell('raspistill -n -w 256 -h 256 -rot 180 -t 0 -o robopi.jpg').

% This is default call - exceptions above for special cases
call_robot(Robot, Behaviour):-
	swarm_behaviour(_Requirements, Behaviour, Code),
	send_to_bot(Robot, Code), !.
call_robot(Robot, Unknown):-
	write('Unknown Behaviour for Robot:'-Robot-':'-Unknown),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the 'Fake' connect to robot stuff for simulation
% Parsing code from Swarmbots ActivityBots 2017
/*
      case 49:              // '1' : initialise
        initialise();
      case 65:              // 'A' : robot_halt
        robot_halt();
      case 66:              // 'B' : ahead
          go_ahead();
      case 67:              // 'C' : left
          go_left();
      case 68:              // 'D' : right
          go_right();
      case 69:              // 'E' : reverse
          go_reverse();
      case 70:              // 'F' : navigateP
          navigateP();
      case 71:              // 'G' : navigateIR
          navigateIR();
      case 72:              // 'H' : navigatePIR
          navigatePIR();
      case 73:              // 'I' : navigateBIR
          navigateBIR();
       case 74:              // 'J' : navigatePBIR
          navigatePBIR();
      case 75:              // 'K' : navigateB2IR
          navigateB2IR();
      case 76:              // 'L' : navigatePB2IR
          navigatePB2IR();
      case 77:              // 'M' : slowPB2IR
          slowPB2IR();
      case 78:              // 'M' : slowP
          slowP();
      case 79:              // 'O' : circleP
          circleP();

----------------------------------------------------------
      case 80:              // 'P' : roamP
          roamP();
      case 81:              // 'Q' : roamBIR
          roamBIR();
      case 82:              // 'R' : roamPBIR
          roamPBIR();
      case 83:              // 'S' : roamB2IR
          roamB2IR();
      case 84:              // 'T' : roamPB2IR
          roamPB2IR();
      case 85:              // 'U' : sonar_swarm_on_object
          sonar_swarm_on_object();

----------------------------------------------------------
      case 97:              // 'a' : set_obstacle_range
          set_obstacle_range();
      case 98:              // 'b' : sonar_sensor
        sonar_sensor();
      case 99:              // 'c' : sonar_obstacle
          sonar_obstacle();
      case 100:             // 'd' : ir_obstacle
          ir_obstacle();
      case 101:             // 'e' : sonar_ir_obstacle
          sonar_ir_obstacle();
      case 102:             // 'f' : set BLOCK_ir_obstacle range voltage
          set_ir_block_range();
      case 103:             // 'g' : single BLOCK_ir obstacle range voltage
          ir_block_obstacle();     // Assume on pin 3
      case 104:             // 'h' : sonar single BLOCK_ir obstacle range voltage
          sonar_ir_block_obstacle();     // Assume on pin 3
      case 105:             // 'i' : Double BLOCK_ir obstacle range voltage
          ir_2block_obstacle();     // Assume on pin 1 and 2
      case 106:             // 'j' : sonar DOUBLE BLOCK_ir obstacle range voltage
          sonar_ir_2block_obstacle();     // Assume on pin 1 and 2
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% communication to/from robot (swarmbots)
% If simulator
send_to_bot(Robot, Message):-
	cncmode(cognoncog, simulator),
	run_simulator( Robot, Message ),
	!.
% special exceptions to	general rule
% send_to_bot(Host, 48), % make transparent
% replaced with
% Pred = send_to_robot, Args = [Host, exit],
send_to_bot(Robot, exit):-
	connection(Robot, _S, _R, W),
	put_byte(W, 48), !,
	flush_output(W).

send_to_bot(Robot, Message):-
	connection(Robot, _S, _R, W),
	put_byte(W, Message), !,
	flush_output(W).
send_to_bot(Robot, Message):-
	writeln('** Message to Bot failed:'-Robot-':Code:'-Message),
	!.

send_from_bot(Robot, Message):-
	connection(Robot, _S, R, _W),
	get_byte(R, Message), !,
	write('Robot sent: '), writeln(Message),
	!.

%	flush_output(R).
send_from_bot(Robot, Message):-
	write('** Message from Bot failed'),
	write(Robot),
	write(' Message: '), writeln(Message),
	!.

% if in simulator ythis is the interface to that code
run_simulator( Robot, Message ):-
	sim_robot_mapping( _SwarmId, AgtId, Robot ),
	agent_sensory_data(AgtId, Return ),
	write('\t\t> Agent Has sensed : '),
	writeln( Return ),
	write('\t\t> Now code the behaviour via : '),
	writeln( run_simulator( Robot, Message ) ),
	!.

%eof synthetic-single-interface.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comments only between full line delimiters to end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof














%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File synthetic-swarm~single.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% updated from swarmdemo.pl to work with synthetic-graphics.pl
% dnd
% 27 april 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These predicates determine the processes and actions of single agent
% Loaded by swarmdemo.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code originally to enable prolog to connect and manage TCP/IP
% sockets to swarm robots 30/01/2014 onwards This version for the
% swarmII-pi3 combination Need to use this library for TCP/IP interfaces
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rather than use
%  ActivityBots (swarmBots)
%  Pioneer P3DX~CogBot as Host
%  AmigoBots as independent activity
% simulator to be used
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VAST majority of code moved to
%   synthetic-swarm~interface.pl
%   THERE the actual interface occurs
%   HERE IS SWARM abd AGENT behaviour definition and selection
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the current database of robots and environment objects
% robot_id/3
% robot_id(Name, Address, Port).
% These are required for robot wifi ~ open option
robot_id(swarmI, '192.168.0.10', 2000).
robot_id(swarmII, '192.168.0.11', 2000).
robot_id(swarmIII, '192.168.0.12', 2000).
robot_id(swarmIV, '192.168.0.13', 2000).
robot_id(swarmV, '192.168.0.14', 2000).
robot_id(swarmVI, '192.168.0.15', 2000).
robot_id(swarmVII, '192.168.0.16', 2000).
robot_id(swarmVIII, '192.168.0.17', 2000).
robot_id(swarmIX, '192.168.0.18', 2000).
robot_id(swarmX, '192.168.0.19', 2000).

% updated for simulated pi
% used to be captured by robot_pi_id/3
robot_id(pi1, '192.168.0.25', 2000).
robot_id(pi2, '192.168.0.26', 2000).
robot_id(pi3, '192.168.0.27', 2000).

/*
% These may not be applicable here
robot_pi_id(daenerys, '192.168.0.25', 2000).
robot_pi_id(cersei, '192.168.0.26', 2000).
robot_pi_id(melisandre, '192.168.0.27', 2000).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% what am i?
% robot_config/3 computational and sensor specification
% robot_config(Name, RaspBerryPi, [sonar, ir2block, picamera]).
robot_config(swarmI, pi2, [sonar, ir2block, picamera]).
robot_config(swarmII, pi3, [sonar, ir2block, picamera]).
robot_config(swarmIII, pi1, [sonar, ir2block, picamera]).
robot_config(swarmIV, null, [sonar]).
robot_config(swarmV, null, [sonar]).
robot_config(swarmVI, null, [sonar, sonar_left, sonar_right]).
robot_config(swarmVII, null, [sonar]).
robot_config(swarmVIII, null, [sonar, ir2block]).
robot_config(swarmIX, null, [sonar, ir2block]).
robot_config(swarmX, null, [sonar, ir2block]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use default_robot_behaviour for independent robots
:- dynamic(default_robot_behaviour/2).
default_robot_behaviour(swarmI, navigatePB2IR).
default_robot_behaviour(swarmII, navigatePB2IR).
default_robot_behaviour(swarmIII, navigatePB2IR).
default_robot_behaviour(swarmIV, navigateP).
default_robot_behaviour(swarmV, navigateP).
default_robot_behaviour(swarmVI, navigateP).
default_robot_behaviour(swarmVII, navigateP).
default_robot_behaviour(swarmVIII, navigatePB2IR).
default_robot_behaviour(swarmIX, navigatePB2IR).
default_robot_behaviour(swarmX, navigateP).
default_robot_behaviour( _AnyOther, navigate).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use default_swarm_behaviour for swarm robots
:- dynamic(default_swarm_behaviour/2).
default_swarm_behaviour(swarmI, roamP).
default_swarm_behaviour(swarmII, roamP).
default_swarm_behaviour(swarmIII, roamP).
default_swarm_behaviour(swarmIV, circleP).
default_swarm_behaviour(swarmV, roamP).
default_swarm_behaviour(swarmVI, roamP3).
default_swarm_behaviour(swarmVII, sonarswarm).
default_swarm_behaviour(swarmVIII, sonarswarm).
default_swarm_behaviour(swarmIX, roamP).
default_swarm_behaviour(swarmX, roamP).
default_swarm_behaviour(_AnyOther, roam).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End of database for single swarm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set_swarm_behaviourset/4
% set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList )
set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ):-
	Host = Host,
	SwarmBehaviour = cognoncog,
	present_swarm_behaviours(swarm1, haphazard, _RList),
	set_swarm_behaviourset( haphazard, SwarmId, SwarmList ),
%	set_haphazard_behaviourset( Host, SwarmId, SwarmList ),
	!.
set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ):-
	Host = simulator,
	SwarmBehaviour = cognoncog,
	present_swarm_behaviours(SwarmId, _SBehaviour, _RList), !,
	set_swarm_behaviourset( default, SwarmId, SwarmList ),
	!.
set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ):-
	writeln('\t> unknown arg combination in predicate '),
	writeln('\t ': set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ) ),
	nl,
	!.

% given no constraint
% Enable random configuration of behaviour sets
% set_haphazard_behaviourset( Host, SwarmId, SwarmList )
set_swarm_behaviourset( Mode, SwarmId, [] ):-
	Mode = Mode,
	SwarmId = SwarmId,
	!.
set_swarm_behaviourset( Mode, SwarmId, [RobotId|SwarmList] ):-
	% reset current_robot_behaviour/2
	select_robot_behaviour( Mode, RobotId, NewBehaviour ),
	reset_robot_behaviour( RobotId, NewBehaviour ),
	set_swarm_behaviourset( Mode, SwarmId, SwarmList ),
	!.

% haphazard ie pseudorandom
select_robot_behaviour( haphazard, RobotId, NewBehaviour ):-
	sim_robot_mapping( _SwarmId, _AgtId, RobotId ),
	robot_config(RobotId, _Pi, SensorList),
	full_behaviour_set( SensorList, Behaviours ),
	% map onto swarm_behaviour(Sensors, Behaviour, CodeNo)
	length( Behaviours, BLen ),
	Index is random( BLen ), % Range {0, ,,, BLen-1}
	nth0( Index, Behaviours, NewBehaviour ),
	!.
% exception clause > default behaviour
select_robot_behaviour( default, RobotId, Default ):-
	sim_robot_mapping( SwarmId, AgtId, RobotId ),
%	SwarmId = SwarmId, AgtId = AgtId,
%	sim_robot_mapping( SwarmId, SwarmAgent, Robot ),
	default_robot_behaviour( RobotId, Default),
	update_swarm_behaviours( SwarmId, AgtId-Default ),
	!.
% haphazard ie pseudorandom
select_robot_behaviour( Mode, RobotId, NewBehaviour ):-
	sim_robot_mapping( _SwarmId, _AgtId, RobotId ),
	robot_config(RobotId, Pi, SensorList),
	full_behaviour_set( SensorList, Behaviours ),
	write('\t> '), writeln(select_robot_behaviour( Mode, RobotId, NewBehaviour ) ),
	write('\t> '), writeln(robot_config(RobotId, Pi, SensorList)),
	write('\t> '), writeln( full_behaviour_set( SensorList, Behaviours ) ),
	% map onto swarm_behaviour(Sensors, Behaviour, CodeNo)
%	length( Behaviours, BLen ),
%	Index is random( BLen ), % Range {0, ,,, BLen-1}
%	nth0( Index, Behaviours, NewBehaviour ),
	!.

reset_robot_behaviour( RobotId, NewBehaviour ):-
	current_robot_behaviour( RobotId, OldB),
	retract( current_robot_behaviour( RobotId, OldB) ), !,
	reset_robot_behaviour( RobotId, NewBehaviour ),
	!.
reset_robot_behaviour( RobotId, NewBehaviour ):-
	assert( current_robot_behaviour( RobotId, NewBehaviour ) ),
	!.

% full_behaviour_set\2
% full_behaviour_set( SensorList, Behaviours )
% needs to map from
%   :- dynamic(swarm_behaviour/3).
%   swarm_behaviour([], shut_down, 48).
full_behaviour_set( [], Behaviours ):-
	findall(Behaviour, swarm_behaviour([], Behaviour, _Code), FullList ),
	delete(FullList, shut_down, Behaviours),
	!.
full_behaviour_set( SensorList, Behaviours ):-
	findall(Behaviour, swarm_behaviour(SensorList, Behaviour, _Code), List1 ),
	length( SensorList, SLen ),
	Index is random( SLen ), % Range {0, ,,, BLen-1}
	nth0( Index, SensorList, DelSense ),
	delete(SensorList, DelSense, NewSensorList ),
	full_behaviour_set( NewSensorList, List2 ),
	append(List1, List2, Behaviours ),
	!.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this code below runs single agent
choose_behaviours(_Id, []):-
	!.
choose_behaviours(Id, [Robot|Robots]):-
	find_behaviours(Robot, Behaviours),
	current_robot_behaviour(Robot, Current),
	length(Behaviours, N),
	writeln('Choosing Behaviours'-Id-Robot-Current),
	writeln('Select 1 to '-N-' for choice - 0 for current'),
	write_numbered_list(1, Behaviours),
%	writeln(N-'Choices: '-Behaviours),
	read(X), number( X ), !,
	select_behaviour_from_list(Robot, X, Behaviours),
	choose_behaviours(Id, Robots).

/* cut
write_numbered_list(_N, []):- !.
write_numbered_list(N, [B|Behaviours]):-
	writeln('\t :'-N-B),
	M is N+1,
	write_numbered_list(M, Behaviours).
 to here */

select_behaviour_from_list(_Robot, 0, _Behaviours):-
	!.
select_behaviour_from_list(Robot, Choice, Behaviours):-
	nth1(Choice, Behaviours, Behaviour),
	change_robot_behaviour( Robot, Behaviour ),
	!.

find_behaviours(Robot, Behaviours):-
	robot_config(Robot, _Pi, Capabilities),
	findall(Behaviour,
		(   swarm_behaviour(Requirements, Behaviour, _Code),
		    requirements_capabilities(Requirements, Capabilities) ),
		Behaviours).

% generic call to robot to change behaviour
robot_behaviour(Robot, Code):-
	swarm_behaviour(Requirements, Behaviour, Code),
	robot_config(Robot, _Pi, Capabilities),
	requirements_capabilities(Requirements, Capabilities),
	change_robot_behaviour( Robot, Behaviour ).
robot_behaviour(Robot, Behaviour):-
	swarm_behaviour(Requirements, Behaviour, _Code),
	robot_config(Robot, _Pi, Capabilities),
	requirements_capabilities(Requirements, Capabilities),
	change_robot_behaviour( Robot, Behaviour ).
robot_behaviour(Robot, Code):-
	write('Unknown Behaviour or capabilities mismatch: '),
	writeln(Robot-Code), !.

change_robot_behaviour( Robot, Behaviour ):-
	current_robot_behaviour(Robot, Old),
	retract( current_robot_behaviour(Robot, Old) ), !,
	assert( current_robot_behaviour(Robot, Behaviour) ),
	Call =.. [call_robot, Robot, Behaviour],
	Call, !.
change_robot_behaviour( Robot, Behaviour ):-
	assert( current_robot_behaviour(Robot, Behaviour) ),
	Call =.. [call_robot, Robot, Behaviour],
	Call, !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
requirements_capabilities([], _Capabilities):- !.
requirements_capabilities([Head|Requirements], Capabilities):-
	member(Head, Capabilities),
	requirements_capabilities(Requirements, Capabilities).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For Information only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the 'Fake' connect to robot stuff for simulation
% Parsing code from Swarmbots ActivityBots 2017
/*
      case 49:              // '1' : initialise
        initialise();
      case 65:              // 'A' : robot_halt
        robot_halt();
      case 66:              // 'B' : ahead
          go_ahead();
      case 67:              // 'C' : left
          go_left();
      case 68:              // 'D' : right
          go_right();
      case 69:              // 'E' : reverse
          go_reverse();
      case 70:              // 'F' : navigateP
          navigateP();
      case 71:              // 'G' : navigateIR
          navigateIR();
      case 72:              // 'H' : navigatePIR
          navigatePIR();
      case 73:              // 'I' : navigateBIR
          navigateBIR();
       case 74:              // 'J' : navigatePBIR
          navigatePBIR();
      case 75:              // 'K' : navigateB2IR
          navigateB2IR();
      case 76:              // 'L' : navigatePB2IR
          navigatePB2IR();
      case 77:              // 'M' : slowPB2IR
          slowPB2IR();
      case 78:              // 'M' : slowP
          slowP();
      case 79:              // 'O' : circleP
          circleP();

----------------------------------------------------------
      case 80:              // 'P' : roamP
          roamP();
      case 81:              // 'Q' : roamBIR
          roamBIR();
      case 82:              // 'R' : roamPBIR
          roamPBIR();
      case 83:              // 'S' : roamB2IR
          roamB2IR();
      case 84:              // 'T' : roamPB2IR
          roamPB2IR();
      case 85:              // 'U' : sonar_swarm_on_object
          sonar_swarm_on_object();

----------------------------------------------------------
      case 97:              // 'a' : set_obstacle_range
          set_obstacle_range();
      case 98:              // 'b' : sonar_sensor
        sonar_sensor();
      case 99:              // 'c' : sonar_obstacle
          sonar_obstacle();
      case 100:             // 'd' : ir_obstacle
          ir_obstacle();
      case 101:             // 'e' : sonar_ir_obstacle
          sonar_ir_obstacle();
      case 102:             // 'f' : set BLOCK_ir_obstacle range voltage
          set_ir_block_range();
      case 103:             // 'g' : single BLOCK_ir obstacle range voltage
          ir_block_obstacle();     // Assume on pin 3
      case 104:             // 'h' : sonar single BLOCK_ir obstacle range voltage
          sonar_ir_block_obstacle();     // Assume on pin 3
      case 105:             // 'i' : Double BLOCK_ir obstacle range voltage
          ir_2block_obstacle();     // Assume on pin 1 and 2
      case 106:             // 'j' : sonar DOUBLE BLOCK_ir obstacle range voltage
          sonar_ir_2block_obstacle();     // Assume on pin 1 and 2
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- consult('./synthetic-swarm~interface.pl').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof synthetic-single-agent.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comments only between full line delimiters to end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof






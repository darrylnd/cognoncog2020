%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% D.N. Davis
% 25 March 1998
% Flocking added 21 April 1998
% Storyboard added 25 April 1998
% Tidied Up For Teaching November 1998
% Modified code November 2000
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
% Updated to fit with synthetic swarm
% 14 april 2020
% Updated to fit with synthetic-swarm~interface.pl predicates
% 06 mai 2020
% dnd
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prolog And Graphical Interface for Some Ideas From
%  Braitenberg : Vehicles: experiments in Synthetic Psychology
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
readme:-
	prolog code for graphics environment
				some interative simple agents and swarm
	synthetic-swarm.pl		version of swarmdemo.pl restructured for use with synthetic-graphics.pl
	swarmdemo.pl		legacy code for small robots and their swarm control 
				< needs small constructed propellor~plus~pi robots and wifi infrastructure >
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
useof:-
	synthetic-graphics.pl
				can be used by itself (no swarms)
				type 'graphics_go.' and use buttons
	synthetic-swarm~drones.pl
				loaded by synthetic-graphics.pl
				predicates and code for running drone agents created via graphics
				can step, cycle or flock (not swarm)
	synthetic-swarm.pl
				loads 'synthetic-graphics.pl' and other files
				type 'swarm_go.' and use buttons		
	synthetic-swarm~single.pl
				loaded by synthetic-swarm.pl
				predicates and code for running single agents within a swarm
	synthetic-swarm~interface.pl
				loaded by synthetic-swarm~single.pl
				predicates and code for simulating single agents/robots within a swarm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof

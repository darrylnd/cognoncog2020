%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File: synthetic-graphics.pl
% D.N. Davis
% 25 March 1998
% Flocking added 21 April 1998
% Storyboard added 25 April 1998
% Tidied Up For Teaching November 1998
% Modified code November 2000
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
% Updated to fit with synthetic swarm
% 14 april 2020
% dnd
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prolog And Graphical Interface for Some Ideas From
%  Braitenberg : Vehicles: experiments in Synthetic Psychology
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Local behaviour in artificial life systems is often built in,
%   whereas global behaviour is often emergent." [Franklin 1995 p.186]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is, perhaps, the basis for a study in the emergent
%	properties of a distributed synthetic intelligence
% Chambers Twentieth Century Dictionary (p:1370)
%	synthesis: the combination of seperate elements of thought
%			into a whole:
%		 : reasoning from principles to a conclusion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Two Dimensional Simulation using Synthetic Agents
% Phase1 agents are very simple reflexive agencies
%  Represented graphically as Empty Circles
%  And Two prolog predicates
%	agent(Id, Xcoord, Ycoord, Radius)
%	agent_atts(Id, SenseRange, Field, Velx, Vely, Attached)
%
%   Default values for these parameters are:
%	Xcoord, Ycoord random placements
%		around source based on Velocity in X and Y directions
%   Velocity is in X and Y directions (i.e. a 2D vector)
%	avoids doing computationally expensive angle stuff!
%	Both can be -ve or +ve in range 0-10
%		though initially random in range -5 to +5
%   Radius by default is 10
%   SenseRange is by default 50 (5 times radius)
%   Field is Radius plus 2 and defines @physical@ extent of agent
%   Attached is by default false
%	and defines whether agent is held, or holding something
%	If agent held takes value true
%	If agent holds energytool then takes value etool
%
%  They can move around the environment
%   sensing anything in the environment within their SenseRange
%   avoiding each other and anything else in the environment
%  Their implicit drive is to simply keep moving
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Phase2 synthetic agents can have explicit drives
%  these are represented using the predicate agent_drive
%  For example, they can have energy levels which need replenishing
%	agent_drive(energy, LEVEL, State, Goals)
%  More on that later - but not in this package!
%	Develop your own
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Border of the environment is impenetrable
%  Agents emerge from a dark hole
%   graphically represented as black filled circle
%   and prolog predicate
%	 source(IDENTIFIER, Xcoord, YCoord, Radius)
%   agents can escape from the demonstrator through this too!
%  Other objects that exist are
%   energy sources
%    graphically represented as red filled circles
%    and prolog predicate
%	 esource(IDENTIFIER, Xcoord, Ycoord, Radius)
%    Agents can feed from it IF AND ONLY IF
%	they are Attached to an energytool
%	prolog predicate
%	 tool(energy,Attached)
%       which they can get from the
%   tool box
%   graphically represented as blue filled circle
%   and prolog predicate
%	toolbox(IDENTIFIER, Xcoord, Ycoord, Radious)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DANGER Will Robinson!
%	agents without an energy tool
%	that get within a specified distance of
%	the energy source are eaten!
%	This distance is 1.5 times the agents field
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DANGER Will Robinson!
%	energy sources that touch borders or source
%	implode to nothingness
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Extensions will (in time) add other kinds of agents
%  i. Information agents
%	that inform user/agents about all the agents and objects
%  ii. Rational agents
%	that reason about what the other agents are doing!
%  iii. Reasoning agents that perform reasoning tasks
%  iv. Memory agents, that remeber!
%  v. Goal agents that manage goals
%  vi. Varieties of complex agents
%	that are any combination of the above!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modules required
:- use_module(library(pce)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dynamic predicates used for simulation
:-	dynamic(display/3),
	dynamic(dialog/1),
	dynamic(browser/1),
	% generic graphics objects
	dynamic(source/4),		% one predicate defines source
	dynamic(esource/4),		% one predicate defines energy source
	dynamic(entity_size/2),		% predicate defines size of objects, energy, drone, agent etc.
	dynamic(object_list/1),
	% drone agent lists
	dynamic(agent_list/1),
	dynamic(agent/4),		% three predicates define agent
	dynamic(agent_atts/6),
	dynamic(agent_nature/3),
	% swarm dynamics
	dynamic(swarm_id_list/1),
	dynamic(swarm_list/1),
	dynamic(swarm_color/1),
	dynamic(swarm_list/3),
	%
	dynamic( cycle_step_definition/1 ),
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% default and initialisation values
% swarm_id_list/1
% swarm_list/1
% agent_list/1
% object_list/1
swarm_id_list([]).
swarm_list([]).
agent_list([]).
object_list([]).

% top level graphics start
% graphics_config(Height, Width, Colour)
graphics_config( 750, 1000, lightcyan).
% graphics_go/0
graphics_go:-
	initialise,
	graphics.

% The Graphics Window Stuff
% Makes use of the O-O Based Graphics Interface XPCE
% graphics/0
graphics:-
	graphics_config(Height, Width, Colour),
	new( P, picture('SASS: Synthetic Agents and Swarm Simulation', size(Width, Height)) ),
	send(P, colour, colour(Colour)),
	assert( display(P, Width, Height) ),
	send( new(B, browser), right, P),
	send( new(D, dialog), below, B),
	assert( dialog(D) ),
	assert( browser(B) ),
% SWI-Prolog without XPCE dislikes the @prolog
	send(D, append, button(quit, message(@prolog, tidysimgraphics))),
	send(D, append, button(reset, message(@prolog, reset))),
	send(D, append, button(info, message(@prolog, info))),
	send(D, append, button(mkenergy, message(@prolog, make_energy))),
	send(D, append, button(mkagent, message(@prolog, make_agent))),
	send(D, append, button(step, message(@prolog, step))),
	send(D, append, button(flock, message(@prolog, flock))),
	send(D, append, button(addswarm, message(@prolog, add_swarm))),
	send(D, append, button(addswagt, message(@prolog, add_swarmagent))),
	send(D, append, button(swarminfo, message(@prolog, swarm_info))), % text display
	send(D, append, button(swarm, message(@prolog, run_swarm))),
	send(D, append, button(stepAll, message(@prolog, step_all))),
	send(D, append, button(stepN, message(@prolog, cycle_all))),
	send(P, open),
	make_source(P, 50, 150, 150).

graphic_message(Message):-
	browser(B),
	send(B, append, Message ),
	!.
tidysimgraphics:-
	browser(B),
	retract( browser(B) ),
	findall( Bvar, retract( browser( Bvar ) ), _BvarList),
	dialog(D),
	retract( dialog(D) ),
	findall( Dvar, retract( dialog(Dvar) ), _DvarList ),
	display(P, Width, Height),
	retract( display(P, Width, Height) ),
	findall( Pvar, retract( display(Pvar, _W, _H) ), _PvarList ),
%	send(P, destroy ), !,
	send(B, destroy ), !,
%	send(D, destroy),
	tidysimgraphics,
	!.
tidysimgraphics:-
	writeln('\t>>tidy agent info too'),
	writeln('>>>>>>> >>>>>>> >>>>>>> >>>>>>>'),
	writeln('>>>>>>> >>>>>>> know why 42 is not a solution >>>>>>> >>>>>>>'),
	writeln('>>>>>>> >>>>>>> ok, 42 ... 42 what? >>>>>>> >>>>>>>'),
	writeln('>>>>>>> >>>>>>> >>>>>>> >>>>>>>'),
	nl,
	!.
tidysimgraphics:-
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/*
 *	dynamic(entity_size/2),		% predicate defines size of objects, energy, drone, agent etc.
	dynamic(agent/4),		% three predicates define agent
	dynamic(agent_atts/6),
	dynamic(agent_nature/3),
	dynamic(source/4),		% one predicate defines source
	dynamic(esource/4),		% one predicate defines energy source
 */
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% agents defined and run in code below <this file> are "drones"
%  and run via calls to predicates in file synthetic-swarm~drones.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% General predicates for all entities
%   entity_size/2
%         entity_size( EntityKey, Diameter )
% entity_size( EntityKey, Diameter ).
entity_size( hole, 50).
entity_size( energy, 30).
entity_size( droneagt, 20).
entity_size( swarmagt, 25).
entity_size( other, 15).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Following predicates define objects and entities
%   source/4
%        source(AgtOriginId, LocationX, LocationY, Size)
%   esource/4
%	 esource(EnergyId, LocationX, LocationY, Size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Following predicates define agent
%   agent/4
%	 agent(AgentId,B,C,D),
%   agent_atts/6
%	agent_atts(AgentId, _, MinD, Velx, Vely, _),
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initial configuration values
% what color are swarm agents
swarm_color( green ).
%
cycle_step_definition( 10 ).

%
swarm_colour_list([ green, darkmagenta, darkorange, darkgoldenrod, darkcyan, dark_slate_blue, darkgreen, grey ]). % i E [0, 8] :|- I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Top Level of agent - explicit energy drive
% This could have some goal to feed off
%	energy sources and if altruistic then redistribute it.
% Different "emotive" drives
%  can result in differing interpretations of self and others
%  can result in differing intentions
%  can result in differing actions
%  can result in changes to perceptual filters
%  can result in chnages to 'self' or interpretation of

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% swarm agents are those created and run from within
%  the file:
%	    synthetic-swarm.pl
%  ensure added to swarm_list/1
%	write('\t>>> Use this predicate add_swarm/0 to create NEW swarm	: agents coloured >>>> ':Color), nl,
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add_swarm/0
%  called via graphics button first time called > no swarm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
add_swarm:-
	swarm_list([]), !,
	%writeln('\t> variety zero on add_swarm/0'),
	make_swarm( SwAgt ),
	%retract( swarm_list(SwarmId, Color, Agents) ),
	%assert( swarm_list(SwarmId, Color, [SwAgt|Agents]) ),
	retract( swarm_list([]) ),
	assert( swarm_list([SwAgt]) ).
add_swarm:-
	swarm_list(_SwarmId, _Color, _Agents),
	swarm_list(SwarmList),
	%writeln('\t> variety one on add_swarm/0':swarm_list(SwarmId, Color, Agents)),
	make_swarm( SwAgt ),
	%retract( swarm_list(SwarmId, Color, Agents) ),
	%assert( swarm_list(SwarmId, Color, [SwAgt|Agents]) ),
	retract( swarm_list(SwarmList) ),
	assert( swarm_list([SwAgt|SwarmList]) ).
% add_swarm/0 exception/incomplete etc.
add_swarm:-
%	swarm_list(SwarmId, Color, Agents),
	writeln('\t> variety two on add_swarm/0 > should not be called if all else working'),
	swarm_list(SwarmList),
	write('\t\t> '), writeln( SwarmList ),
%	trace,
	make_swarm( SwAgt ),
%	retract( swarm_list(SwarmId, Color, Agents) ),
%	assert( swarm_list(SwarmId, Color, [SwAgt]) ),
	retract( swarm_list(SwarmList) ),
	assert( swarm_list([SwAgt|SwarmList]) ),
	notrace, nodebug,
	!.
make_swarm( SwarmAgent ):-
	gensym('swarm',SwarmId),
	retract( swarm_id_list(IdList) ),
	assert( swarm_id_list([SwarmId|IdList]) ),
	length( IdList, NSw ),
	change_swarm_color(NSw, Color),
	make_swarm_configuration( SwarmId ),
	%write('\t>>New Swarm :- ':SwarmId:Color:' ' ), writeln([SwarmId|IdList]),
	make_synthetic( SwarmId, SwarmAgent ),
	% now call synthetic-swarm predicate to set that up
	make_synthetic_control( SwarmId, SwarmAgent ),
	% start predicate swarm_list/3 for swarm
	assert( swarm_list(SwarmId, Color, [SwarmAgent]) ),
	!.

%  add_swarmagent/0 called via graphics button
%  first time called > no swarm
add_swarmagent:-
	swarm_list([]), !,
	%nl,
	%writeln(' >>>> add_swarmagent/0 Entry 0:- []'),
	%write('\t>>> Use this predicate add_swarmagent/0 to create swarm agents>>>>'), nl,
	add_swarm.
add_swarmagent:-
	swarm_id_list([SwarmId|_IdList]),
	swarm_list(SwarmId, Color, SwarmAgents),
	swarm_list(SwarmList),
	%write(' >>>> add_swarmagent/0 Entry 1:- ' ), writeln(SwarmList),
	%write('\t>>> Use this predicate add_swarmagent/0 to create swarm agents>>>>'), nl,
	make_swarmagent( SwAgt ), !,
	retract( swarm_list(SwarmId, Color, SwarmAgents) ),
	assert( swarm_list(SwarmId, Color, [SwAgt|SwarmAgents]) ),
	retract( swarm_list(SwarmList) ),
	assert( swarm_list([SwAgt|SwarmList]) ).
add_swarmagent:-
%	swarm_list(SwarmId, Color, SwarmAgents),
	swarm_list(SwarmList),
	%write('\t>> add_swarmagent/0 Entry 2:- ' ), writeln(SwarmList),
	%write('\t>>> Use this predicate add_swarmagent/0 to create swarm agents>>>>'), nl,
	make_swarmagent( SwAgt ), !,
	%write(' >>>> add_swarmagent/0 Entry 2:- ':SwAgt:' ' ), writeln(SwarmList),
%	retract( swarm_list(SwarmId, Color, SwarmAgents) ),
%	assert( swarm_list(SwarmId, Color, [SwAgt|SwarmAgents]) ),
	retract( swarm_list(SwarmList) ),
	assert( swarm_list([SwAgt|SwarmList]) ).


% This predicate acting on swarm and agent
% make_swarmagent/1
% returns SwarmAgent
make_swarmagent( SwarmAgent ):-
	% called before any swarm created
	swarm_id_list([]), !,
% so create that  first and agent
	make_swarm( SwarmAgent ),
	!.
make_swarmagent( SwarmAgent ):-
	swarm_id_list([SwarmId|_List]),
	make_synthetic( SwarmId, SwarmAgent ),
	%write(' >>>> make_swarmagent/1 Entry 2:- ' ), writeln( SwarmAgent ),
	% now call synthetic-swarm predicate to set that up
	make_synthetic_control( SwarmId, SwarmAgent ),
	!.

% make_synthetic/2
% make_synthetic( SwarmId, SwarmAgent )
% given SwarmId, create and return SwarmAgent
make_synthetic( SwarmId, SwarmAgent ):-
	display(P, _, _),
	gensym('swrmagt',SwarmAgent),
	gen_velocity(5, Velx),
	gen_velocity(5, Vely),
	assert(agent_atts(SwarmAgent, 50, 12, Velx, Vely, false)),
	entity_size( swarmagt, Size),
	make_agt_loc(SwarmAgent, X, Y),
	assert(agent(SwarmAgent, X, Y, Size)),
	send(P, display, new(GId, circle(Size)), point(X, Y)),
	swarm_color( Color ),
	send(GId, fill_pattern, colour( Color )),
	assert(agent_nature(SwarmAgent, GId, swarm-SwarmId /*swarm*/)),
	% not this line
	% add_agent(A).
	!.

% End of that code
% change_swarm_color/2
% change_swarm_color(Index, Color)
% Base Case > no existing swarm
change_swarm_color(0, Color):-
	swarm_color( Color ),
	% writeln('\t\tInitial swarm coloured : ':Color),
	!.
% Index Color List
change_swarm_color(Index, NewC):-
	swarm_color( Color ),
	swarm_colour_list(CList),
	length(CList, NLen),
	NLen > Index, !,
	nth0(Index, CList, NewC),
	% write('\t\tNew swarm '),write(Index), writeln(' colour from:':Color:' to: ':NewC),
	retract( swarm_color( Color ) ),
	assert( swarm_color( NewC ) ),
	!.
% Subtract and recurse
change_swarm_color(Index, Color):-
	writeln('t> Swarm Index greater than Color list : '),
	swarm_colour_list(CList),
	length(CList, NLen),
	NewIndex is Index - NLen, !,
	change_swarm_color(NewIndex, Color),
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% predicates to run a swarm
% interactive via graphics or direct
% more in
%        synthetic-swarm.pl
%        synthetic-swarm~single.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% run_swarm/0
run_swarm:-
	swarm_id_list(SwarmIdList),
	%nl,
	%writeln('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	%write('\t>> Current Swarm Id List:- ' ), writeln(SwarmIdList),
	swarm_list(SwarmList),
	%write('\t>> Current SwarmList:- ' ), writeln(SwarmList),
	%write('\t>>> Use predicate run_swarm/0 to call operation of swarm agents>>>>'), nl,
	% call to run_swarm/2 in synthetic~swarm
	run_swarm( SwarmIdList, SwarmList ).

step_all:-
	NumberofCycles = 1,
	step( NumberofCycles ),
	run_swarm.  % modify to step multiple times
% cycle_all/0
cycle_all:-
	cycle_step_definition( Step ),
	step( Step ),
	run_swarm.  % modify to step multiple times

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% A list of toolkit support predicates
% add_agent/1
add_agent(Agt):-
	retract(agent_list(Agts)), !,
	assert(agent_list([Agt|Agts])).

%collect_agents/1
% Simplistic at the moment - could specify extra constraints
%	based on agent attributes?
collect_agents([A|Agts]):-
	agent(A,B,C,D),
	retract(agent(A,B,C,D)),!,
	collect_agents(Agts),
	assert(agent(A,B,C,D)).
collect_agents([]).

% count_agents/1
count_agents(N):-
	clause(agent(_,_,_,_),_),
	findall(Agt, agent(Agt,_,_,_), Agts),
	length(Agts, N).
count_agents(0).

% add_object/1
add_object(Obj):-
	retract(object_list(Objs)), !,
	assert(object_list([Obj|Objs])).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set of make thing(s) predicates
% This is where the agents emerge from!
% make_source/4
make_source(P, D, X, Y):-
	send(P, display, new(C, circle(D)), point(X, Y)),
	send(C, fill_pattern, colour(black)),
	assert(source(C, X, Y, D)),
	add_object(C).

% energy source
% make_energy/0
make_energy:-
	display(P, W, H),
	X is random(W),
	Y is random(H),
	entity_size( energy, Size),
	send(P, display, new(E, circle( Size )), point(X, Y)),
	send(E, fill_pattern, colour(red)),
	assert(esource(E, X, Y, Size)),
	add_object(E).

delete_object(Obj):-
	retract(source(Obj, _, _, _)), !,
	retract(object_list(Objects)),
	delete(Objects, Obj, NewList),
	assert(object_list(NewList)).
delete_object(Obj):-
	retract(esource(Obj, _, _, _)), !,
	retract(object_list(Objects)),
	delete(Objects, Obj, NewList),
	assert(object_list(NewList)).

% delete_all_objects/1
delete_all_objects([]).
delete_all_objects([Obj|Objs]):-
	delete_object(Obj),
	delete_all_objects(Objs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Following predicates used to make DRONE agents
% Make A Simple Synthetic Agent - Called From Graphical Interface
% Make xORy location for agent within display
% make_loc/3
make_loc(X, Max, Min):-
	X is random(Max),
	X > Min.
make_loc(X, Max, Min):-
	make_loc(X,Max,Min).

% gen_velocity/2
gen_velocity(Max, Vel):-
	Z is random(2),
	Z > 0,
	Vel is random(Max).
gen_velocity(Max, Vel):-
	Vel is -1*(random(Max)).

% Simplist form of synthetic agent
% Enter the environment from the dark circle!
% make_agt_loc/3
make_agt_loc(A, X, Y):-
	source(_, Xs, Ys, Ss),
	display(_, W, H),
	agent_atts(A, _, MinD, Velx, Vely, _),
	MinX is ( ((Xs-Ss)-MinD) - (2*abs(Velx)) ),
	MaxX is ( W-((Xs+Ss)+MinD) + (2*abs(Velx)) ),
	make_loc(X, MaxX, MinX),
	X < (W-MinD),
	X > MinD,
	MinY is ( ((Ys-Ss)-MinD) - (2*abs(Vely)) ),
	MaxY is ( W-((Ys+Ss)+MinD) + (2*abs(Vely)) ),
	make_loc(Y, MaxY, MinY),
	Y < (H-MinD),
	Y > MinD, !.
	%notclose_to_any_agent(X, Y, MinD).

/* alt version
	display(P, W, H),
	X is random(W),
	Y is random(H),

 *  */
% make_agent/0
make_agent:-
	display(P, _, _),
	gensym('agent',A),
	gen_velocity(5, Velx),
	gen_velocity(5, Vely),
	assert(agent_atts(A, 50, 12, Velx, Vely, false)),
	make_agt_loc(A, X, Y),
	entity_size( droneagt, Size),
	assert(agent(A, X, Y, Size)),
	send(P, display, new(GId, circle(Size)), point(X, Y)),
	send(GId, fill_pattern, colour(yellow)),
	assert(agent_nature(A, GId, reflexive)),
	add_agent(A).
%	moveagent(A,X,Y).

% delete_agent/1
delete_agent(Agt):-
	retract(agent(Agt, _, _, _)), !,
	retract(agent_atts(Agt, _, _, _, _, _)),
	retract(agent_nature(Agt, GId, _)),
	retract(agent_list(Agents)),
	delete(Agents, Agt, NewList),
	assert(agent_list(NewList)),
	send(GId, destroy).

% delete_all_agents/1
delete_all_agents([]).
delete_all_agents([Agt|Agts]):-
	delete_agent(Agt),
	delete_all_agents(Agts).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set of utility predicates
% set of utility predicates
build_string([],'').
build_string([S|Strings], Returned):-
	build_string(Strings, SR),
	is_list(S), !,
	build_string(S,SL),
	string_concat(SL, SR, Returned).
build_string([S|Strings], Returned):-
	build_string(Strings, SR),
	string_concat(S, SR, Returned).

% agent_info/1
agent_info([]):-
	count_agents(N), N > 0, !.
agent_info([]):-
	graphic_message(' Currently there are no agents'), nl.
agent_info([Agt|Rest]):-
	agent(Agt,X,Y,S),
	agent_atts(Agt, SenseD, MinD, Velx, Vely, Attach),
	agent_nature(Agt, _Var1, Nature),
	graphic_message('***** Agent Information : '),
	build_string(['   ', Agt], S1),
	graphic_message(S1),
	build_string(['   X-Y Position : ', X, ' - ', Y], S2),
	graphic_message(S2),
	build_string(['  Velx : Vely : ', Velx, ' - ', Vely], S3),
	graphic_message(S3),
	build_string(['  Size Radius : ', S], S4),
	graphic_message(S4),
	build_string(['  Agent Space : ',MinD], S5),
	graphic_message(S5),
	build_string(['  Sense Range : ', SenseD], S6),
	graphic_message(S6),
	build_string(['  Attachments : ',Attach], S7),
	graphic_message(S7),
	build_string(['  Agent Nature: ', Nature], S8),
	graphic_message(S8),
	sense_agent(Agt, Senses),
	build_string(['  Senses: ', Senses], S9),
	graphic_message(S9),
	agent_info(Rest).

% info/0
info:-
	collect_agents(Agents),
	agent_info(Agents).

% Reset called from graphics window
% Simply removes all the agents
% reset/0
reset1:-
	agent_list(Agts),
	delete_all_agents(Agts),
	object_list(Objs),
	delete_all_objects(Objs).

reset:-
	reset1,
	display(P, _Varx, _Vary),
	make_source(P, 50, 150, 150).

% ensure previous things cleaned away
% initialise/0
initialise:-
	reset1,
	retractall(display(_V1,_V2,_V3)),
	retractall(source(_V4,_V5,_V6,_V7)),
	retractall(browser(_V8)),
	retractall(dialog(_V9)).
%	send(D, destroy)
initialise:-
	reset1,
	retractall(display(_V1,_V2,_V3)),
	retractall(source(_V4,_V5,_V6,_V7)),
	retractall(browser(_V8)).
initialise.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set of predicates that run the little thing
% synthetic-swarm~drones.pl has more on drone movement
% generic run objects
% run_objects/2
run_objects(Behaviour, Args):-
	Term =.. [Behaviour | Args],
	call(Term).

% run_object/1
% source does nothing at the moment!
% BUT could give agent extra capability if within certain range
% Or change their DRIVES if not currently doing anything?
run_object(Obj):-
	source(Obj,_V1,_V2,_V3).
run_object(Obj):-
	esource(Obj,_V1,_V2,_V3),
	agent_list(Agts),
	run_objects(check_on_capture, [Agts]),
	object_list(Objects),
	delete(Objects, Obj, Rest),
	run_objects(esource_limits, [Obj, Rest]).

% run_objects/1
run_objects([]).
run_objects([Obj|Objects]):-
	run_object(Obj),
	run_objects(Objects).

% step_agents/1
% Phase 1 : calculate new position
% Phase 2 : move agent to new position
% Extend this for default agent processes and behaviours
step_agents([]).
step_agents([Agt|Rest]):-
	calculate_position(Agt, NewX, NewY),
	moveagent(Agt, NewX, NewY),
	step_agents(Rest).

% generic run_agent predicate
% run_agents/3
run_agents(Behaviour, Args, Objects):-
	Term =.. [Behaviour | Args],
	call(Term),
	run_objects( Objects ).

% step/1
step(0).
step(N):-
	M is N-1,
	agent_list(Agts),
	object_list(Objects),
	run_agents(step_agents, [Agts], Objects),
	step(M).

% step/0
step:-
	step(1).

% flock/0
flock:-
	agent_list(Agents),
	length(Agents, N),
	N > 1,
	object_list(Objects),
	run_agents(flock, [Agents, Agents], Objects),
	run_objects(Objects).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This loaded here to allow flock+drone agents only
:- consult('./synthetic-swarm~drones.pl').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof



















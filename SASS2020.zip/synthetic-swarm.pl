%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% synthetic-swarm.pl
% updated from swarmdemo.pl to work with synthetic-graphics.pl
% dnd
% 14 april 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These predicates determine the processes and actions of single agent
% Loaded by
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code originally to enable prolog to connect and manage TCP/IP
% sockets to swarm robots 30/01/2014 onwards This version for the
% swarmII-pi3 combination Need to use this library for TCP/IP interfaces
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/* References to previous work robot and cog agent
 *  see Support.pl for full documentation
 *
  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 sources for concepts (whether in agreement or otherwise ...)


  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
   These are selected papes that provide context for concepts associated
    with current focus and original use of this updated 2020 simulator
     ~ these relate to prolog, poplog, lisp and other implementations

 Darryl N Davis, Shylaja Kanaganapalli Ramulu
        Reasoning with BDI Robots: From simulation to physical environment � Implementations and Limitations,
            Journal of Behavioural Robotics, Volume 8, 2017.
 D.N. Davis and H. Miri
       Probabilistic BDI in a Cognitive Robot Architecture,
            International Journal of Computer Science and Artificial Intelligence (IJCSAI), Vol.2 No.3: 1-10, September, 2012.
 M.V.Vijayakumar, D.N.Davis, K.R.Shylaja, Vishwanth Y, and E.V.Prasad
        Computational Testbeds For Synthetic and Robotic Agents
            International MultiConference of Engineers and Computer Scientists (IMECS 2011),IAENG Hong Kong, 16-18 March, 2011.
            ISBN: 978-988-18210-3-4
 D.N. Davis & J. Gwatkin
        robo-CAMAL: A BDI Motivational Robot
            Journal of Behavioral Robotics, 1(2), Pages 116-129, July 2010.
 D.N. Davis & Vijayakumar M V
        A "Society of Mind" Cognitive Architecture based on the Principles of Artificial Economics.
            International Journal of Artficial Life Research.1(1):51-71, January 2010.
 D.N. Davis
        Cognitive Architectures for Affect and Motivation
            Cognitive Computation 2(3), September 2010.
 Davis, D.N.
        Linking perception and action through motivation and affect
            Journal of Experimental & Theoretical Artificial Intelligence, Vol. 20, 1, Marc h 2008 , pages 37 - 60.
 Davis, D.N. (Editor).
        Visions of Mind: Architectures for Cognition and Affect
            Collected work, IDEA Group Publishing. ISBN:159140483-5, March 2005.
 Davis, D.N.
        Why do anything? Emotion, affect and the fitness function underlying behaviour and thought.
            Affective Computing, AISB 2004, University of Leeds, UK.
 Davis, D.N.
        Affect and Affordance: Architectures without Emotion
            AAAI 2004, Stanford University, California, USA
 Davis, D.N. & Lewis, S.J.
        Computational Models of Emotion for Autonomy and Reasoning.
            Informatica (Special Edition on Perception and Emotion Based Reasoning), 27(2):159-165, 2003.
 Davis, D.N.
        Architectures for Cognitive and A-Life Agents
            Chapter, In: Intelligent Agent Software Engineering,
            V. Plekhanova (eds.), IDEA Group Publishing, ISBN:
	    1-59140-046-5; eISBN: 1-59140-084-8, 2003
 Davis, D.N.
        Computational Architectures for Intelligence and Motivation,
            IEEE Systems & Intelligent Control, Vancouver, Canada, 2002.
 Davis, D.N.
        Cellular Automata, Computational Emotion and Autonomy,
            International Conference on Computational Intelligence for Modelling, Control and Automata, Las Vegas, USA. July 2001.
 D.N.Davis
       Multiple Level Representations of Emotion in Computational Agents,
            Emotion, Cognition and Affective Computing, AISB2001:Agents and Cognition, University of York, March 2001. isbn: 1 902956 19 7
 Davis, D.N.
        Control States and Complete Agent Architectures
            Computational Intelligence (An International Journal), 17(4):621-650, 2001.
 D.N. Davis,
        Agents, Emergence, Emotion and Representation,
            Emergent Behaviour of Complex Human-Machine Interaction (Session Chair),
            IEEE International Conference on Industrial Electronics, Control and Instrumentation (IECON2000)
            Nagoya, Japan 2000.
 Davis, D.N.
        Agents, Emergence, Representation and Emotion,
            International Workshop on Complex Systems
            Kyoto University, Kyoto, Japan, October 2000.
 Davis, D.N.
        Computational Emergence and Computational Emotion,
            Proceedings of IEEE Symposium on Systems, Man and Cybernetics, Tokyo, October 1999.
 Davis, D.N.and Berbank-Green, B.
        Towards An Architecture for A-life Agents,
            Int.l Conf. on Computational Intelligence for Modelling, Control and Automation, Vienna, February,
 Davis, D.N.
        Synthetic Agents: Synthetic Minds? Frontiers in Cognitive Agents,
             IEEE Symposium on Systems, Man and Cybernetics, San Diego, October 1998.
*/

/*
 * Impetus for current testbed
 *
 i.   partly by curiousity to implement simplified emotive engine (4D)
 ii. partly by need to leave physical robots alone
     > bogged down in electro-mechanical frippery
     > slow development
     > auld robot swarm
 iii. partly by requirements of resercahr for
	Curiousity Driven Dynamic Reconfiguration of Swarm Robots
	  Using Simple Behaviours
 etc.
	      */

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% after last review paper on cognoncog research using robots
%  and other environmental constraints (first half 2020)
%  robots put aside for other use now > point proven
%  simulator faster to work on < not all those little
%    electro-mechanical deviosonical issues to deal with
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set mode for synthetic~swarm :
%                 simulator mode by default
%                 swarmbots mode was basis for swarm code
%                 others to complete
% used in synthetic-swarm~interface.pl etc.
%         to determine nature of communication
% cncmode/2
% cncmode( COGNITIONMODEL, TESTBED )
cncmode(cognoncog, simulator).
% mode(cognoncog, swarmbots).
% mode(cognoncog, camal).
% mode(cognoncog, scarab).
% mode(cognoncog, aria).
% mode(cognoncog, amigobots).
% mode(cognoncog, p3dx).
% mode(cognoncog, colony).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define library odules to be used
:- use_module( library(socket) ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These predicates only used with "actual robots"
% self(robot, swarmI).
% self(pi, cersei).
:- dynamic( self/2 ).
% host_robot(swarmI).
:- dynamic( host_robot/1 ).
% host_robot(swarmI, pi2).
:- dynamic( host_robot/2 ).

% This is used to manage the swarms
% dynamic/3 robot_swarm
% robot_swarm(Id, HostRobot, [Swarm List]).
:- dynamic(robot_swarm/3).

% present_swarm_configuration/3
% present_swarm_configuration( SwarmId, Host, SwarmBehaviour)
% Host simulator, aria, mobilesim, hostX, p3dx,  etc.
% SwarmMode is Keyword(s) for Current overall swarm pattern
%  extend set of keywords to suit (eg affective states)
% Keyword |- { cognoncog, camal, scarab, swarmbot, amigobot, aria,
% <vector> } etc
:- dynamic( present_swarm_configuration/3 ).

% present_swarm_behaviours/3
% present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours).
% SwarmBehaviour as defined in present_swarm_behaviour or variations
:- dynamic( present_swarm_behaviours/3 ).

% present_swarm_sensing/3
% see use in sensory data in synthetic-swarm~interface.pl
:- dynamic( present_swarm_sensing/3 ).
present_swarm_sensing( cognoncog, simulator, range).
%present_swarm_sensing( cognoncog, simulator, boundingbox).
%present_swarm_sensing( cognoncog, simulator, sensorarc).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This database could be in
%    synthetic-swarm~single.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% code to run raspberry pi with swarmbot
% predicate for database of behaviours
% common across all swarm robots with or without embedded pi
% swarm_behaviour([Requirements], BEHAVIOUR, BEHAVIOUR_CODE).
% Requirements is an AND List
% OR List taken care of by means of alternative predicate instances
:- dynamic(current_robot_behaviour/2).
:- dynamic(swarm_behaviour/3).
swarm_behaviour([], shut_down, 48).
swarm_behaviour([], initialise, 49).
swarm_behaviour([], halt, 65).
swarm_behaviour([], go_ahead, 66).
swarm_behaviour([], go_left, 67).
swarm_behaviour([], go_right, 68).
swarm_behaviour([], go_reverse, 69).
swarm_behaviour([sonar], navigateP, 70).
swarm_behaviour([ir], navigateIR, 71).
swarm_behaviour([sonar, ir], navigatePIR, 72).
swarm_behaviour([irblock], navigateBIR, 73).
swarm_behaviour([sonar, irblock], navigateBIR, 74).
swarm_behaviour([ir2block], navigateB2IR, 75).
swarm_behaviour([sonar, ir2block], navigatePB2IR, 76).
swarm_behaviour([sonar, ir2block], slowPB2IR, 77).
% swarm behaviours
swarm_behaviour([sonar], roam, 78).
swarm_behaviour([sonar], circleP, 79).
swarm_behaviour([sonar], roamP, 80).
swarm_behaviour([irblock], roamBIR, 81).
swarm_behaviour([sonar, irblock], roamPBIR, 82).
swarm_behaviour([ir2block], roamB2IR, 83).
swarm_behaviour([sonar, ir2block], roamPB2IR, 84).
swarm_behaviour([sonar, sonar_left, sonar_right], roamP3, 85).
swarm_behaviour([sonar], sonarswarm, 86).

% sensory behaviours
swarm_behaviour([sonar], set_obstacle_range, 97).
swarm_behaviour([irblock], set_obstacle_range, 97).
swarm_behaviour([ir2block], set_obstacle_range, 97).
swarm_behaviour([sonar], sonar_sensor, 98).
swarm_behaviour([sonar], sonar_obstacle, 99).
swarm_behaviour([ir], ir_obstacle, 100).
swarm_behaviour([sonar, ir], sonar_ir_obstacle, 101).
swarm_behaviour([irblock], set_ir_block_range, 102).
swarm_behaviour([ir2block], set_ir_block_range, 102).
swarm_behaviour([irblock], ir_block_obstacle, 103).
swarm_behaviour([ir2block], ir_block_obstacle, 103).
swarm_behaviour([sonar, irblock], sonar_ir_block_obstacle, 104).
swarm_behaviour([ir2block], ir_2block_obstacle, 105).
swarm_behaviour([sonar, ir2block], sonar_ir_2block_obstacle, 106).
% The following behaviours are on pi and not to propellor board
swarm_behaviour([picamera], take_pi_image, 150).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/* required by
%	SwarmBehaviour = cognoncog, % default setting
	present_swarm_configuration( SwarmId, Host, SwarmBehaviour), !,
*/
	% Of all possible configurations
	%  initial predicate for simulator~cognoncog only
make_swarm_configuration( SwarmId ):-
	Host = simulator,
	SwarmMode = cognoncog, % default setting
	assert( present_swarm_configuration( SwarmId, Host, SwarmMode ) ),
	SwarmBehaviour = roam, % default behaviour
	MemberBehaviours = [], % no swarmagents yet
	assert( present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours) ),
	!.

update_swarm_behaviours( SwarmId, AgtId-Default ):-
	present_swarm_behaviours( SwarmId, SwarmBehaviour, []),
	retract( present_swarm_behaviours( SwarmId, SwarmBehaviour, []) ),
	assert( present_swarm_behaviours( SwarmId, SwarmBehaviour, [AgtId-Default]) ),
	!.
update_swarm_behaviours( SwarmId, AgtId-Default ):-
	present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours),
	remove_from_swarm_behaviours(AgtId, MemberBehaviours, Reduced),
	retract( present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours) ),
	assert( present_swarm_behaviours( SwarmId, SwarmBehaviour, [AgtId-Default|Reduced]) ),
	!.

remove_from_swarm_behaviours(_AgtId, [], []):-
	!.
remove_from_swarm_behaviours(AgtId, [AgtId-Behaviour|Reduced], Reduced):-
	Behaviour = Behaviour,
	!.
remove_from_swarm_behaviours(AgtId, [AGENTId-Behaviour|Rest], [AGENTId-Behaviour|Reduced]):-
	remove_from_swarm_behaviours(AgtId, Rest, Reduced),
	!.
%/* legacy code?
% make a swarm
make_swarm(Id, Host, RobotList):-
	gensym(swarm, Id),
	SwarmBehaviour = cognoncog, % default setting
	write('\t\t> '), writeln( make_swarm(Id, Host, RobotList) ),
	assert( present_swarm_configuration( Id, Host, SwarmBehaviour) ),
	assert( robot_swarm(Id, Host, RobotList) ).
%*/
dissolve_swarm( SwarmId ):-
	retract( present_swarm_configuration( SwarmId, Host, SwarmBehaviour) ),
	retract( present_swarm_behaviours( SwarmId, SwarmBehaviour, _MemberBehaviours) ),
	retract( robot_swarm(SwarmId, Host, _Robotlist) ),
%	retract( robot_swarm(SwarmId, Host, _SwarmList) ),
	dissolve_swarm_mappings( SwarmId ),
	!.
dissolve_swarm( SwarmId ):-
	write('\t\tDissolve swarm failed for '), writeln( SwarmId ),
	!.
dissolve_swarm_mappings( SwarmId ):-
	sim_robot_mapping( SwarmId, SwarmAgent, Robot ), !,
	retract( sim_robot_mapping( SwarmId, SwarmAgent, Robot ) ),
	dissolve_swarm_mappings( SwarmId ),
	!.
dissolve_swarm_mappings( SwarmId ):-
	SwarmId = SwarmId,
	!.

% display all swarm information as text
swarm_info:-
	swarm_id_list(SwarmIdList),
	swarm_info( SwarmIdList ),
	!.
swarm_info([]):-
	writeln('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	nl,
	!.
swarm_info([SwarmId|SList]):-
	writeln('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	present_swarm_configuration( SwarmId, Host, SwarmMode),
	writeln( present_swarm_configuration( SwarmId, Host, SwarmMode) ),
	robot_swarm(SwarmId, Host, Robotlist),
	writeln( robot_swarm(SwarmId, Host, Robotlist) ),
	present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours),
	writeln( present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours) ),
	swarm_info( SList ),
	!.

which_swarm( Robot, Id ):-
	robot_swarm(Id, _Host, Robots),
	member(Robot, Robots).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% top level predicate to start graphics and simple swarm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
swarmgo:-
	graphics_go,
	% this can be extended with specific calls
	% eg copy and modify any of the following
/*
  swarm1
  swarm2
  swarmX(RList)
  demo(RobotList)
  exp
  exp(Host)
  s(Code)
 */
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/*
 This is known at this call for SwarmAgent
	display(P, _, _),
	gensym('swrmagt',SwarmAgent),
	gen_velocity(5, Velx),
	gen_velocity(5, Vely),
	assert(agent_atts(SwarmAgent, 50, 12, Velx, Vely, false)),
	make_agt_loc(SwarmAgent, X, Y),
	assert(agent(SwarmAgent, X, Y, 15)),
	send(P, display, new(GId, circle(15)), point(X, Y)),
	send(GId, fill_pattern, colour( green )),
	assert(agent_nature(SwarmAgent, GId, swarm)),
 */
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- dynamic( sim_robot_mapping/3 ).
% sim_robot_mapping( SwarmAgent, Robot, SwarmId )
make_synthetic_control( SwarmId, SwarmAgent ):-
	robot_swarm(SwarmId, Host, SwarmList),
	%writeln('\t>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	%writeln('\t  Make a swarm agent ':SwarmAgent),
	%writeln('\t  Existing swarm:- '),
	%writeln('\t   ':SwarmId:' Host ':Host:' Agents ':SwarmList),
	assign_robot( SwarmId, Robot ),
	assert( sim_robot_mapping( SwarmId, SwarmAgent, Robot ) ),
	retract( robot_swarm(SwarmId, Host, SwarmList) ),
	assert( robot_swarm(SwarmId, Host, [Robot|SwarmList]) ),
%
	% access
	% robot_id(swarmI, '192.168.0.10', 2000) to find fresh one
	!.
make_synthetic_control( SwarmId, SwarmAgent ):-
	%writeln('\t>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	%writeln('\t Make a swarm agent ':SwarmAgent),
	%writeln('\t swarm ':SwarmId),
	assign_robot( SwarmId, Robot ),
	assert( sim_robot_mapping( SwarmId, SwarmAgent, Robot ) ),
	assert( robot_swarm(SwarmId, simulator, [Robot]) ),
% robot_swarm(Id, HostRobot, [Swarm List])
	% access
	% robot_id(swarmI, '192.168.0.10', 2000) to find fresh one
	!.
%!	%
%
assign_robot( SwarmId, Robot ):-
	robot_id( Robot, _IAddrr, _Port),
	% SwarmAgent = Robot,
	SwarmId = SwarmId,
	not( sim_robot_mapping( _SwarmId , _SwarmAgent, Robot ) ),
	!.
%
/* Code tomodify
 start_swarm(Id, [Robot | RobotList]):-
	make_swarm(Id, Robot, [Robot | RobotList]),
	connect_swarm(Id), !.
start_swarm(Id, Robot, RobotList):-
	make_swarm(Id, Robot, RobotList),
	connect_swarm(Id), !.
end_swarm(Id):-
	disconnect_swarm(Id),
	dissolve_swarm( Id ),
	clean_up.

swarm_cycle(Id):-
	writeln(Id-'Any key to continue'),
	swarm_info(Id),
	writeln('c for cycles - b to define behaviour - q to stop'),
	get_char(X), !,
	swarm_pause_or_halt(Id, X), !.
swarm_cycle(_Id):- !.

 */
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% interface from synthetic~graphics
% call to run_swarm/2
run_swarm( SwarmIdList, SwarmList ):-
	writeln('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	write('\t>run_swarm/2 '), writeln(run_swarm( SwarmIdList, SwarmList )),
	writeln('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'),
	run_swarm( SwarmIdList),
	!.

run_swarm( [] ):-
	!.
run_swarm( [ SwarmId | SwarmIdList ] ):-
	robot_swarm(SwarmId, Host, SwarmList), !,
	%write('\t\t>run_swarm/1: Swarm found and running: '), writeln(SwarmId),
	run_one_swarm( SwarmId, Host, SwarmList ),
	run_swarm( SwarmIdList ),
	!.
run_swarm( [ SwarmId | SwarmIdList ] ):-
	write('\t\t>run_swarm/1: Swarm not found : '), writeln(SwarmId),
	%Host, SwarmList), !,
	run_swarm( SwarmIdList ),
	!.

run_one_swarm( SwarmId, Host, SwarmList ):-
	%write('\t\t>run_one_swarm/3 : '), write(SwarmId ),
	%write(' '), write( Host ), write(' with '), writeln( SwarmList ),
	choose_swarm_behaviour(  SwarmId, Host, SwarmList ),
	run_swarm_behaviours( SwarmId, Host, SwarmList ),
	!.

% choose_swarm_behaviour/3
% Following predicate determines which behaviour set swarm runs
% Up to researcher/developer to determine what goes on here
% present_swarm_behaviour(SwarmId, SwarmBehaviour, MemberBehaviours)
choose_swarm_behaviour(  SwarmId, Host, SwarmList ):-
	% decision combination of what swarm wants to do and capabilities of swarm members
	% could set up default behaviour for swarm and decide whether to chnage
	% here behaviours set almost at random
	SwarmBehaviour = cognoncog, % default setting
	present_swarm_configuration( SwarmId, Host, SwarmBehaviour), !,
	%writeln('\t>0: Predicate choose_swarm_behaviour/3 (and support) are what need to be edited'),
	set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ),
	!.
choose_swarm_behaviour(  SwarmId, Host, SwarmList ):-
	% decision combination of what swarm wants to do and capabilities of swarm members
	% could set up default behaviour for swarm and decide whether to chnage
	% here behaviours set almost at random
	% SwarmBehaviour = cognoncog, % default setting
	present_swarm_configuration( SwarmId, Host, SwarmBehaviour),
	%writeln('\t>1:Predicate choose_swarm_behaviour/3 (and support) are what need to be edited'),
	set_swarm_behaviourset( SwarmBehaviour, Host, SwarmId, SwarmList ),
	!.

% This predicate one that runs ENTIRE set of agents in this swarm
run_swarm_behaviours( SwarmId, Host, SwarmList ):-
	%writeln('\t>2:Predicate run_swarm_behaviours/3 (and support) are what need to be edited'),
	% present_swarm_configuration( Host, SwarmId, SwarmBehaviour)
	% present_swarm_behaviours( SwarmId, SwarmBehaviour, MemberBehaviours)
	present_swarm_behaviours(SwarmId, SwarmBehaviour, MemberBehaviours), %What swarm and what swarmagent have need not agree
	SwarmBehaviour = SwarmBehaviour,
	%write('\tHost '), write( Host ), write(' Overall Swarm Behavior : '), writeln( SwarmBehaviour ),
	call_swarm_agents( Host, SwarmList, MemberBehaviours ),
	!.

call_swarm_agents( _Host, [], [] ):-
	!.
call_swarm_agents( Host, [RobotId|SwarmList], [SwrmAgt-MBehave|MemberBehaviours]):-
	sim_robot_mapping( _SwarmId, SwrmAgt, RobotId ),
	calltoagent( Host, RobotId, MBehave ),
	call_swarm_agents( Host, SwarmList, MemberBehaviours ),
	!.
call_swarm_agents( Host, SwarmList, [SwrmAgt-MBehave|MemberBehaviours]):-
	% not this sim_robot_mapping( _SwarmId, SwrmAgt, RobotId ),
	append(MemberBehaviours,[SwrmAgt-MBehave],NewL),
	call_swarm_agents( Host, SwarmList, NewL ),
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mixture of old and new code > unpredictable
% robot specific predicates - experiment
swarm1:-
	start_swarm(Id, swarmI, [swarmI, swarmIX, swarmX]), !,
	end_swarm(Id).
swarm2:-
	run_default_swarm( [swarmI, swarmVIII, swarmX] ), !.
swarmX(RList):-
	run_default_swarm(RList).

demo(RobotList):-
	start_swarm(Id, RobotList), !,
%	run_default_behaviours( RobotList ),
	run_swarm_behaviours( RobotList ),
	!,
	swarm_cycle(Id), !,
	end_swarm(Id).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  short cut with self/2 host_robot/1 host_robot/2
exp:-
	clean_up,
	define_self( swarmI ),
	host_robot(Host),
	robot_connect(Host, S, R, W),
	assert( connection(Host, S, R, W) ).
fin:-
	host_robot(Host),
	% send_to_bot(Host, 48),  % make transparent
	% replaced with
	calltoagent(Host, exit),
	!.
exp(Host):-
	clean_up,
	robot_connect(Host, S, R, W),
	assert( connection(Host, S, R, W) ).
fin(Host):-
	% send_to_bot(Host, 48),  % make transparent
	% replaced with
	calltoagent(Host, exit),
	!.

s(Code):-
	host_robot(Host),
	swarm_behaviour(Requirements, Behaviour, Code),
	robot_config(Host, _Pi, Capabilities),
	requirements_capabilities(Requirements, Capabilities),
	Call =.. [call_robot, Host, Behaviour],
	Call, !.
s(Unknown):-
	write('Unknown Behaviour or capabilities mismatch: '),
	writeln(Unknown), !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predicates that would be otherwise missing
define_self( Arg ):-
	writeln('\tOtherwise missing predicate define_self/1 ':Arg),
	!.
run_default_swarm( ListArg ):-
	writeln('\tOtherwise missing predicate run_default_swarm/1 ':ListArg),
	!.

write_numbered_list(_N, []):- !.
write_numbered_list(N, [B|Behaviours]):-
	writeln('\t :'-N-B),
	M is N+1,
	write_numbered_list(M, Behaviours).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

run_swarm_behaviours( [] ):- !.
run_swarm_behaviours( [Robot|RobotList] ):-
	default_swarm_behaviour(Robot, Behaviour),
	change_robot_behaviour( Robot, Behaviour ), !,
	run_swarm_behaviours( RobotList ).

run_default_behaviours( [] ):- !.
run_default_behaviours( [Robot|RobotList] ):-
	default_robot_behaviour(Robot, Behaviour),
	change_robot_behaviour( Robot, Behaviour ), !,
	run_default_behaviours( RobotList ).

start_swarm(Id, [Robot | RobotList]):-
	make_swarm(Id, Robot, [Robot | RobotList]),
	connect_swarm(Id), !.
start_swarm(Id, Robot, RobotList):-
	make_swarm(Id, Robot, RobotList),
	connect_swarm(Id), !.
end_swarm(Id):-
	disconnect_swarm(Id),
	dissolve_swarm( Id ),
	swarm_cleanup.

swarm_cycle(Id):-
	writeln(Id-'Any key to continue'),
	swarm_info(Id),
	writeln('c for cycles - b to define behaviour - q to stop'),
	get_char(X), !,
	swarm_pause_or_halt(Id, X), !.
swarm_cycle(_Id):- !.

/*
% legacy code > not with simulator
swarm_info(Id):-
	robot_swarm(Id, Host, Robots),
	writeln('Swarm:'-Id-Host-Robots),
	robots_info(Robots).
robots_info([]).
robots_info([Robot|Rest]):-
	current_robot_behaviour(Robot, Behaviour),
	writeln('Info: '-Robot-Behaviour),
	robots_info(Rest).
*/
swarm_pause_or_halt(Id, 'c'):-
	writeln('Define INTEGER number of Cycles'),
	read(Number), number(Number ), !,
	swarm_cycle_n(Id, Number),
	swarm_cycle(Id),
	!.
swarm_pause_or_halt(Id, 'b'):-
	robot_swarm(Id, _Host, Robots),
	choose_behaviours(Id, Robots),
	swarm_cycle(Id),
	!.
swarm_pause_or_halt(_Id, 'q'):-
	writeln('Match: q - Halting Swarm Cycle'),
	!.
swarm_pause_or_halt(Id, _Whatever):-
	!, swarm_cycle( Id ).

swarm_cycle_n(_Id, 0):- !.
swarm_cycle_n(Id, N):-
	M is N-1,
	swarm_cycle_n(Id, M).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generic clean swarm and call agent connection predicates
swarm_cleanup:-
	robot_swarm(Id, Host, RobotList),
	retract( robot_swarm(Id, Host, RobotList) ), !,
	end_swarm(Id),
	clean_up, !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modify to single agent
% generic robot cleanup connection predicates
clean_up:-
	robot_swarm(Id, Host, RobotList),
	retract( robot_swarm(Id, Host, RobotList) ), !,
	end_swarm(Id),
	clean_up, !.
clean_up:-
	connection(A,B,C,D),
	retract( connection(A,B,C,D) ), !,
	clean_up, !.
% robot_swarm(SwarmId, Host, SwarmList)
clean_up:-
	robot_swarm(SwarmId, Host, SwarmList),
	retract( robot_swarm(SwarmId, Host, SwarmList) ), !,
	clean_up,
	!.
% sim_robot_mapping( SwarmAgent, Robot, SwarmId )
clean_up:-
	sim_robot_mapping( SwarmId, SwarmAgent, Robot ),
	retract( sim_robot_mapping( SwarmId, SwarmAgent, Robot ) ), !,
	clean_up, !.
clean_up:-
	robot_swarm(Id, Host, RobotList),
	retract( robot_swarm(Id, Host, RobotList) ), !,
	clean_up.
clean_up:-
	current_robot_behaviour(R,B),
	retract( current_robot_behaviour(R,B) ), !,
	clean_up.
clean_up:-
	self(robot, Swarm),
	retract( self(robot, Swarm) ), !,
	clean_up.
clean_up:-
	self(pi, Pi),
	retract( self(pi, Pi) ),
	clean_up.
clean_up:-
	host_robot(Swarm),
	retract( host_robot(Swarm) ),
	clean_up.
clean_up:-
	host_robot(Swarm, Pi),
	retract( host_robot(Swarm, Pi) ),
	clean_up.
clean_up:- !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

/* Modify for swarm level (agent level ???)
clean_up:-
	connection(A,B,C,D),
	retract( connection(A,B,C,D) ), !,
	clean_up, !.
clean_up:-
	robot_swarm(Id, Host, RobotList),
	retract( robot_swarm(Id, Host, RobotList) ), !,
	clean_up.
clean_up:-
	current_robot_behaviour(R,B),
	retract( current_robot_behaviour(R,B) ),
	clean_up.
clean_up:-
	self(robot, Swarm),
	retract( self(robot, Swarm) ),
	clean_up.
clean_up:-
	self(pi, Pi),
	retract( self(pi, Pi) ),
	clean_up.
clean_up:-
	host_robot(Swarm),
	retract( host_robot(Swarm) ),
	clean_up.
clean_up:-
	host_robot(Swarm, Pi),
	retract( host_robot(Swarm, Pi) ),
	clean_up.
clean_up:- !.
*/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load and go
:- consult('./synthetic-graphics.pl').
% loaded in graphics file
% :- consult('./synthetic-swarm~drones.pl').

% Following loaded and it loads further files
:- consult('./synthetic-swarm~single.pl').

% Support Document
:- consult('./Support.pl').

% start directive
:- writeln('>>>>>>> >>>>>>> >>>>>>> >>>>>>>'),
	writeln('\t>> calling swarmgo/0 ~~~=> use graphics'),
%	writeln('>>>>>>> type\t readme for technical info'),
%	writeln('>>>>>>> type\t about for geographical~historical
%	info'),
%	nl, !,
	% comment next line if alt use required
	swarmgo,
	writeln('>>>>>>> >>>>>>> >>>>>>> >>>>>>>'),
	!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/*
?- snlng('cognoncog2020').
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Selecting modal : dorian
        [bflute,cnatural,dflute,eflute,fnatural,gnatural,aflute,bflute]
                sequence space : 13
                space is of dimension: 1 [13]
                        Tensor prime : space : 1 [1]
         bflute gnatural gnatural aflute gnatural cnatural aflute gnatural cnatural aflute cnatural aflute bflute         13 14 may be a number
         bflute space space aflute space cnatural aflute space cnatural aflute cnatural aflute bflute     4 14 may be a number
         bflute aflute aflute aflute aflute cnatural aflute aflute cnatural aflute cnatural aflute bflute         3 14 may be a number
        ...plus some other stuff...on... :cognoncog2020
         ,,,, and watt oui j'aivrie all ,,, [(111,iiiiiii,vii,g)]
         ,,,, and watt oui j'aivrie all ,,, [(103,iiiiiiiiiiiiiiiiiiiiiiii,vvvvv,y)]
         ,,,, and watt oui j'aivrie all ,,, [(110,iiiiii,vi,f)]
         ,,,, and watt oui j'aivrie all ,,, [(111,iiiiiii,vii,g)]
         ,,,, and watt oui j'aivrie all ,,, [(110,iiiiii,vi,f)]
         ,,,, and watt oui j'aivrie all ,,, [(99,iiiiiiiiiiiiiiiiiiii,vvvvi,u)]
         ,,,, and watt oui j'aivrie all ,,, [(111,iiiiiii,vii,g)]
         ,,,, and watt oui j'aivrie all ,,, [(103,iiiiiiiiiiiiiiiiiiiiiiii,vvvvv,y)]
         ,,,, and watt oui j'aivrie all ,,, [(50,iiiiiiiiiiiiiiiiiiiiiii,vvvviiii,x)]
         ,,,, and watt oui j'aivrie all ,,, [(48,iiiiiiiiiiiiiiiiiiiii,vvvvii,v)]
         ,,,, and watt oui j'aivrie all ,,, [(50,iiiiiiiiiiiiiiiiiiiiiii,vvvviiii,x)]
         ,,,, and watt oui j'aivrie all ,,, [(48,iiiiiiiiiiiiiiiiiiiii,vvvvii,v)]
        >>>>>>>>>>>>>>>>>>>>>>>
                nullum cacas:- roman ~~ Mode :99 Random entry ; 110,iiiiii,vi,f
                 singularity at 12: :1054: :10: 1:
                         :(1,i,i,a)
        >>>>>>>>>>>>>>>>>>>>>>>
                nullum cacas:- latin ~~ Mode :99:  Random entry ; 48,iiiiiiiiiiiiiiiiiiiii,vvvvii,v
                        >> larger than:- -12- all the i -(12,iiiiiiiiiii,vvii,l)
                        >> <i*><v*i*> 189 seqsin:- 18:  :12: :12: 3:
                         :(3,iii,iii,c)
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
true.
*/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Support.pl
% :- some background to synthetic-swarm.pl
% dnd
% 7 may 2020
% 15 mai 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loaded by synthetic-swarm.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% left blank is �blank
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/* References to previous work robot and cog agent
 *  see Support.pl for full documentation
 *
 */

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/* References to previous support <v incomplete>
% universities
% unvrsts
    university of nottingham (mathematics)
    university of sussex (biology and psychology)
     ..... library, college, oxford
    heriot-watt university (ai, kbs, programming concepts)
     .....
    university of tromso (computational ecology)
    kyoto university ( cognoncog, culture, creativity )
     ....
    university of south california, san diego ( ..quiet.. )
     ....
    university of rome
     ...
    columbia, manhattan, nyc ( cognition, creativity )

sponsors
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Past funding <incomplete>
% themostobscurelocationtodothis:-
tmstbscrlctntdts:-
 writeln('
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  university cambridge scholarship
   university of nottingham
    foundation degree mathematics
   university of sussex
    foundation biology, cognition, mind
  epsrc msc scholarship
   heriot-watt, edinburgh
  mrc+royal society,
   visual pyschophysics, st. andrews
  mrc+north west health+epsrc
   ai in medicine, cervical cancer detection, computational orthodontics
   .....
  University of Birmingham Vice-Chancellor Grant
  (Architectures for Intelligent Agents),
   .....
  Japanese Society For Promotion of Science
  (Affective Agents),
  Government of Vietnam
   Computational Connectionism (PhD studentship Thuy)
  University of Hull Alumni Development Fund
  (Pioneer 3-DX Robot),
  University of Hull PhD studentships
   (S.J. Lewis, C. Bean, J. Gwatkin, H. Miri)
  University of Hull PhD fee waivers
   (M.V. Vijayakumar, S. Balding)
   ...
  European Union
   Visiting project scholar (project+25%+expenses) University of Rome
  Innovation UK
   Number of commercially sensitive projects
  Government of China
   Computational Connectionism and Data Mining
   Computational Connectionism and Data Discovery
  Government of India
  (visiting scholar award : Shylaja Kanaganapalli Ramulu : Bangalore >
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
background:-
    writeln('
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 sources for concepts (whether in agreement or otherwise ...)

 Minsky, M.L.
   The Society of Mind, William Heinemann Ltd., 1987.
 Simon, H.A.
   Motivational and emotional controls of cognition, Reprinted in Models of Thought, Yale University Press, 29-38, 1979.
 Norman, D.A.
   Twelve issues for cognitive science, Cognitive Science, 4:1-33, 1980.
 McFarland, D.
   Animal Behaviour, Addison Wesley Longman, 1993.
 Rolls, E.T.
   The Brain and Emotion, Oxford University Press, 1999

%  Braitenberg : Vehicles: experiments in Synthetic Psychology

 Wahl, S. and H. Spada, Children�s Reasoning about Intentions,
        Beliefs, and Behavior. Cognitive Science Quarterly, 1: 5-34,
        2000. Baars, B. J. (1997). In the Theater of Consciousness.
        Oxford: Oxford University Press
 Langley, P., Laird, J.E., Rogers, S. (2009)
   Cognitive architectures: Research issues and challenges,
   Cognitive Systems Research 10 (2009) 141�160

 Levesque, H. and R. Reiter, (1998)
   Beyond planning.
   AAAI Spring Symposium on Integrating Robotics Research, Working notes,
   Palo Alto, CA, March 1998

 Hawes, N.,
   A survey of motivation frameworks for intelligent systems,
   Artificial Intelligence, 175 (5-6), p.1020-1036, Apr 2011

 Sun, R., Wilson N. and Lynch, M. (2016)
   Emotion: A Unified Mechanistic Interpretation from a CognitiveArchitecture,
   Cognitive Computation, 8(1), pp 1-14.

 > <an exception hVw ==> heVw
 Lallee, S. and Verschure, P.
   How? What? Who? When? Where? Why? Grounding ontology in the behavior of a situated agent,
   Robotics, 4(2), pp169-193, 2015.

  '),
  !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/*
 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 These are selected papes that provide context for concepts associated
 with current focus and original use of this updated 2020 simulator ~
 these relate to prolog, poplog, lisp and other implementations

 Darryl N Davis, Shylaja Kanaganapalli Ramulu
        Reasoning with BDI Robots: From simulation to physical environment � Implementations and Limitations,
            Journal of Behavioural Robotics, Volume 8, 2017.
 D.N. Davis and H. Miri
       Probabilistic BDI in a Cognitive Robot Architecture,
            International Journal of Computer Science and Artificial Intelligence (IJCSAI), Vol.2 No.3: 1-10, September, 2012.
 M.V.Vijayakumar, D.N.Davis, K.R.Shylaja, Vishwanth Y, and E.V.Prasad
        Computational Testbeds For Synthetic and Robotic Agents
            International MultiConference of Engineers and Computer Scientists (IMECS 2011),IAENG Hong Kong, 16-18 March, 2011.
            ISBN: 978-988-18210-3-4
 D.N. Davis & J. Gwatkin
        robo-CAMAL: A BDI Motivational Robot
            Journal of Behavioral Robotics, 1(2), Pages 116-129, July 2010.
 D.N. Davis & Vijayakumar M V
        A "Society of Mind" Cognitive Architecture based on the Principles of Artificial Economics.
            International Journal of Artficial Life Research.1(1):51-71, January 2010.
 D.N. Davis
        Cognitive Architectures for Affect and Motivation
            Cognitive Computation 2(3), September 2010.
 Davis, D.N.
        Linking perception and action through motivation and affect
            Journal of Experimental & Theoretical Artificial Intelligence, Vol. 20, 1, Marc h 2008 , pages 37 - 60.
 Davis, D.N. (Editor).
        Visions of Mind: Architectures for Cognition and Affect
            Collected work, IDEA Group Publishing. ISBN:159140483-5, March 2005.
 Davis, D.N.
        Why do anything? Emotion, affect and the fitness function underlying behaviour and thought.
            Affective Computing, AISB 2004, University of Leeds, UK.
 Davis, D.N.
        Affect and Affordance: Architectures without Emotion
            AAAI 2004, Stanford University, California, USA
 Davis, D.N. & Lewis, S.J.
        Computational Models of Emotion for Autonomy and Reasoning.
            Informatica (Special Edition on Perception and Emotion Based Reasoning), 27(2):159-165, 2003.
 Davis, D.N.
        Architectures for Cognitive and A-Life Agents
            Chapter, In: Intelligent Agent Software Engineering,
            V. Plekhanova (eds.), IDEA Group Publishing, ISBN:
	    1-59140-046-5; eISBN: 1-59140-084-8, 2003
 Davis, D.N.
        Computational Architectures for Intelligence and Motivation,
            IEEE Systems & Intelligent Control, Vancouver, Canada, 2002.
 Davis, D.N.
        Cellular Automata, Computational Emotion and Autonomy,
            International Conference on Computational Intelligence for Modelling, Control and Automata, Las Vegas, USA. July 2001.
 D.N.Davis
       Multiple Level Representations of Emotion in Computational Agents,
            Emotion, Cognition and Affective Computing, AISB2001:Agents and Cognition, University of York, March 2001. isbn: 1 902956 19 7
 Davis, D.N.
        Control States and Complete Agent Architectures
            Computational Intelligence (An International Journal), 17(4):621-650, 2001.
 D.N. Davis,
        Agents, Emergence, Emotion and Representation,
            Emergent Behaviour of Complex Human-Machine Interaction (Session Chair),
            IEEE International Conference on Industrial Electronics, Control and Instrumentation (IECON2000)
            Nagoya, Japan 2000.
 Davis, D.N.
        Agents, Emergence, Representation and Emotion,
            International Workshop on Complex Systems
            Kyoto University, Kyoto, Japan, October 2000.
 Davis, D.N.
        Computational Emergence and Computational Emotion,
            Proceedings of IEEE Symposium on Systems, Man and Cybernetics, Tokyo, October 1999.
 Davis, D.N.and Berbank-Green, B.
        Towards An Architecture for A-life Agents,
            Int.l Conf. on Computational Intelligence for Modelling, Control and Automation, Vienna, February,
 Davis, D.N.
        Synthetic Agents: Synthetic Minds? Frontiers in Cognitive Agents,
             IEEE Symposium on Systems, Man and Cybernetics, San Diego, October 1998.
*/

/*
 * Impetus for current testbed
 *
 i.   partly by curiousity to implement simplified emotive engine (4D)
 ii. partly by need to leave physical robots alone
     > bogged down in electro-mechanical frippery
     > slow development
     > auld robot swarm
 iii. partly by requirements of research for
	Curiousity Driven Dynamic Reconfiguration of Swarm Robots
	  Using Simple Behaviours
 etc.
	      */
/* self referential recursion, !.
 *  see Support.pl for full documentation
 *
  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% number
% number
% number 42
fkknpblcsnmbrftt:-
    nl,
    writeln('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'),
    writeln('>>\t\tpublication forty-two :- the hVw'),
    % who
    writeln('>>\t\t\t42. Davis,�D.N.and�Berbank-Green, B.'),
    % what
� � writeln('>>\t\t\t� � Towards An Architecture for A-life Agents,'),
    % logical conjunction within a hVw construct? when and where
    % when
����writeln('>>\t\t\t��������Int.l�Conf. on Computational Intelligence for Modelling, Control and Automation, Vienna'),
    % where
    writeln('>>\t\t\t        Vienna, February, 1999'),
    % why
    writeln('>>\t\t\t        {interest, need, travel, vienna}'),
    % how
    writeln('>>\t\t\t        {dnd, air lauda, tram}'),
    writeln('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'),
    nl,
    !.
% number 85
/*
 *  D.N. Davis
        Cognitive Architectures for Affect and Motivation
            Cognitive Computation 2(3), September 2010.
*/
fkknpblcsnmbrtfv:-
    nl,
    writeln('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'),
    writeln('>>\t\tpublication eighty-five :- the hVw'),
    % who
    writeln('>>\t\t\t85. Davis,�D.N.'),
    % what
� � writeln('>>\t\t\t� � Cognitive Architectures for Affect and Motivation,'),
    % where
    % logical conjunction within a hVw construct? when and where
    writeln('>>\t\t\t        Cognitive Computation 2(3)'),
    % when
����writeln('>>\t\t\t��������September 2010'),
    % why
    writeln('>>\t\t\t        {interest, need, journal}'),
    % how
    writeln('>>\t\t\t        {dnd, late nights}'),
    writeln('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'),
    nl,
    !.

fkknrfsnsldlgt:-
    fkknpblcsnmbrftt,
    fkknpblcsnmbrtfv,
    writeln('...over and out...'),
    nl,
    !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
readme:-
    nl,
    writeln('
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% cognoncog : SASS
% SASS : Synthetic Agent Swarm Simulation
% D.N. Davis
% % 06 mai 2020
% dnd
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prolog And Graphical Interface for CogNonCog
% type
%   readme
%   about
%   background
% for further information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
readme:-
	prolog code for graphics environment
				some interactive simple agents and swarm
	synthetic-swarm.pl		version of swarmdemo.pl restructured for use with synthetic-graphics.pl
	swarmdemo.pl		legacy code for small robots and their swarm control
				< needs small constructed propellor~plus~pi robots and wifi infrastructure >
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
useof:-
	synthetic-graphics.pl
				can be used by itself (no swarms)
				type graphics_go. and use buttons
	synthetic-swarm~drones.pl
				loaded by synthetic-graphics.pl
				predicates and code for running drone agents created via graphics
				can step, cycle or flock (not swarm)
	synthetic-swarm.pl
				loads synthetic-graphics.pl and other files
				type swarm_go. and use buttons
	synthetic-swarm~single.pl
				loaded by synthetic-swarm.pl
				predicates and code for running single agents within a swarm
	synthetic-swarm~interface.pl
				loaded by synthetic-swarm~single.pl
				predicates and code for simulating single agents/robots within a swarm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    '),
    nl.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
about:-
    tmstbscrlctntdts,
    !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% onload directive
:-
 readme,
 fkknrfsnsldlgt,
 !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof

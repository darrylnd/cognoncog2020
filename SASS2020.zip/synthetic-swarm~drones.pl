%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File: synthetic-swarm~drones.pl
% D.N. Davis
% 25 March 1998
% Flocking added 21 April 1998
% Storyboard added 25 April 1998
% Tidied Up For Teaching November 1998
% Modified code November 2000
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
% Updated to fit with synthetic swarm
% 14 april 2020
% Created for predicates to run drones
% dnd
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prolog And Graphical Interface for Some Ideas From
%  Braitenberg : Vehicles: experiments in Synthetic Psychology
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Local behaviour in artificial life systems is often built in,
%   whereas global behaviour is often emergent." [Franklin 1995 p.186]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is, perhaps, the basis for a study in the emergent
%	properties of a distributed synthetic intelligence
% Chambers Twentieth Century Dictionary (p:1370)
%	synthesis: the combination of seperate elements of thought
%			into a whole:
%		 : reasoning from principles to a conclusion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Two Dimensional Simulation using Synthetic Agents
% Phase1 agents are very simple reflexive agencies
%  Represented graphically as Empty Circles
%  And Two prolog predicates
%	agent(Id, Xcoord, Ycoord, Radius)
%	agent_atts(Id, SenseRange, Field, Velx, Vely, Attached)
%
%   Default values for these parameters are:
%	Xcoord, Ycoord random placements
%		around source based on Velocity in X and Y directions
%   Velocity is in X and Y directions (i.e. a 2D vector)
%	avoids doing computationally expensive angle stuff!
%	Both can be -ve or +ve in range 0-10
%		though initially random in range -5 to +5
%   Radius by default is 10
%   SenseRange is by default 50 (5 times radius)
%   Field is Radius plus 2 and defines @physical@ extent of agent
%   Attached is by default false
%	and defines whether agent is held, or holding something
%	If agent held takes value true
%	If agent holds energytool then takes value etool
%
%  They can move around the environment
%   sensing anything in the environment within their SenseRange
%   avoiding each other and anything else in the environment
%  Their implicit drive is to simply keep moving
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Phase2 synthetic agents can have explicit drives
%  these are represented using the predicate agent_drive
%  For example, they can have energy levels which need replenishing
%	agent_drive(energy, LEVEL, State, Goals)
%  More on that later - but not in this package!
%	Develop your own
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Border of the environment is impenetrable
%  Agents emerge from a dark hole
%   graphically represented as black filled circle
%   and prolog predicate
%	 source(IDENTIFIER, Xcoord, YCoord, Radius)
%   agents can escape from the demonstrator through this too!
%  Other objects that exist are
%   energy sources
%    graphically represented as red filled circles
%    and prolog predicate
%	 esource(IDENTIFIER, Xcoord, Ycoord, Radius)
%    Agents can feed from it IF AND ONLY IF
%	they are Attached to an energytool
%	prolog predicate
%	 tool(energy,Attached)
%       which they can get from the
%   tool box
%   graphically represented as blue filled circle
%   and prolog predicate
%	toolbox(IDENTIFIER, Xcoord, Ycoord, Radious)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DANGER Will Robinson!
%	agents without an energy tool
%	that get within a specified distance of
%	the energy source are eaten!
%	This distance is 1.5 times the agents field
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DANGER Will Robinson!
%	energy sources that touch borders or source
%	implode to nothingness
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Extensions will (in time) add other kinds of agents
%  i. Information agents
%	that inform user/agents about all the agents and objects
%  ii. Rational agents
%	that reason about what the other agents are doing!
%  iii. Reasoning agents that perform reasoning tasks
%  iv. Memory agents, that remeber!
%  v. Goal agents that manage goals
%  vi. Varieties of complex agents
%	that are any combination of the above!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Following predicates relate to object behaviours

% Sensory Capabalities - !!
notclose_to_agent(A, C, E, F) :-
    agent(A, B, D, _),
    (B-C)*(B-C)+(D-E)*(D-E)>F*F.

notclose_to_any_agent(B, C, D) :-
    agent(_, _, _, _),
    !,
    collect_agents(A),
    notclose_to_any_agent(A, B, C, D).
notclose_to_any_agent(_, _, _) :-
    !.

notclose_to_any_agent([], _, _, _) :-
    !.
notclose_to_any_agent([A|E], B, C, D) :-
    notclose_to_agent(A, B, C, D),
    notclose_to_any_agent(E, B, C, D).

% not close_to_object/4
notclose_to_object(O, X, Y, D):-
	source(O, Xobj, Yobj, S),
	( (((Xobj-X)-S)*((Xobj-X)-S)) + (((Yobj-Y)-S)*((Yobj-Y)-S)) ) > (D*D).
% close_to_object/4
notclose_to_object(O, X, Y, D):-
	esource(O, Xobj, Yobj, S),
	( (((Xobj-X)-S)*((Xobj-X)-S)) + (((Yobj-Y)-S)*((Yobj-Y)-S)) ) > (D*D).

% close_to_object/4
close_to_object(O, X, Y, D):-
	source(O, Xobj, Yobj, S),
	( (((Xobj-X)-S)*((Xobj-X)-S)) + (((Yobj-Y)-S)*((Yobj-Y)-S)) ) < (D*D).
% close_to_object/4
close_to_object(O, X, Y, D):-
	esource(O, Xobj, Yobj, S),
	( (((Xobj-X)-S)*((Xobj-X)-S)) + (((Yobj-Y)-S)*((Yobj-Y)-S)) ) < (D*D).

% If any agent within 1.5*Field and Attach=false
%	Then capture for energy source
% energy_objs/2
energy_objs([],[]).
energy_objs([O1|Rest],[O1|More]):-
	esource(O1, _, _, _),
	energy_objs(Rest, More).
energy_objs([_|Rest],Es):-
	energy_objs(Rest,Es).

% esource_growth/2
esource_growth(Esource, Agt):-
	retract(esource(Esource, X, Y, Size)), !,
	NewSize is (Size+(Size/10)),
	assert(esource(Esource, X, Y, NewSize)),
	delete_agent(Agt),
	assert(eaten(Esource, Agt)).

% esource_capture/2
esource_capture(_, []).
esource_capture(Esource, [Agt|Rest]):-
	agent_atts(Agt, _, F, _, _, false),
	MunchDistance is 3*F/3,
	esource(Esource, Xes, Yes, _),
	close_to_agent(Agt, Xes, Yes, MunchDistance),
	esource_growth(Esource, Agt),
	esource_capture(Esource, Rest).
esource_capture(Esource, [_|Rest]):-
	esource_capture(Esource, Rest).

% check_on_capture/1
check_on_capture([]).
check_on_capture([E|Rest]):-
	agent_list(Agts),
	esource_capture(E, Agts),
	check_on_capture(Rest).

% energy_eater/0
energy_eater:-
	clause(esource(_, _, _, _),_),
	object_list(Objs),
	energy_objs(Objs, Energies),
	check_on_capture(Energies).
energy_eater.

% energy source implodes on contact with other objects
% BUT not other esources - unaffected
%		or agents - it eats them
% esource_limits/2
esource_limits(Esource, _):-
	display(_, W, H),
	esource(Esource, X, Y, S),
	( ((X-S) < 0);
	  ((Y-S) < 0);
	  ((X+S) > W);
	  ((Y+S) > H) ),
	delete_object(Esource).
esource_limits(_, []).
esource_limits(Esource, [Obj|_]):-
	esource(Esource, X, Y, S),
	close_to_object(Obj, X, Y, S),
	delete_object(Esource).
esource_limits(Esource, [_|Rest]):-
	esource_limits(Esource, Rest).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Following predicates relate to agent behaviours

% Sensory Capabalities - !!
% close_to_agent/4
close_to_agent(A, X, Y, D):-
	agent(A, Xagt, Yagt, _),
	( ((Xagt-X)*(Xagt-X)) + ((Yagt-Y)*(Yagt-Y)) ) < (D*D).

% Is Given location X-Y Close To An existing Agent - within distance D?
% close_to_any_agent/4
close_to_any_agent([Agt|_], X, Y, D):-
	close_to_agent(Agt, X, Y, D).
close_to_any_agent([],_,_,_):-
	fail.
close_to_any_agent([_|Rest], X, Y, D):-
	close_to_any_agent(Rest, X, Y, D).

% close_to_any_agent/3
close_to_any_agent(X, Y, D):-
	collect_agents(As),
	close_to_any_agent(As, X, Y, D).

%sense_agent/3
sense_agent(_, [], []).
sense_agent(Agt, [AAgt|Rest], [AAgt|Sensed]):-
	agent(Agt, X, Y, _),
	agent_atts(Agt, SenseD, _, _, _, _),
	close_to_agent(AAgt, X, Y, SenseD),
	sense_agent(Agt, Rest, Sensed).
sense_agent(Agt, [_|Rest], Sensed):-
	sense_agent(Agt, Rest, Sensed).

% sense_agent/2
sense_agent(Agt,Senses):-
	agent_list(Agts),
	delete(Agts, Agt, AList),
	sense_agent(Agt, AList, Senses).
sense_agent(_,[]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Agent Movement

% Calculate new X-Y position given just agent
% Currently missing SAFE Distance Constraint using MinD
%	Now in moveagent
% calculate_position/3
calculate_position(Agt, NX, NY):-
	agent(Agt, X, Y, _),
	agent_atts(Agt, _, _, Velx, Vely, _),
	NX is X+Velx,
	NY is Y+Vely.

% Calculate new Velcity-X & Velocity-Y
% given Old Vel-X-Y, and CofG-X-Y and existing X-Y
% Do not worry about collisions at this point
% Safe distance parameter (MinD) used in moveagent
% Could allow agent to "decide" the extent of movement towards CofG

% Simply calculate new position on basis of existing
%	position X-Y and Velocity in X and Y
% calculate_position/3
% Can safely change agent velocity here so that it nevers hit display border
calculate_position(Agt, NX, NY):-
	agent(Agt, X, Y, _),
	agent_atts(Agt, _, _, Velx, Vely, _),
	NX is (X+Velx),
	NY is (Y+Vely).

% Move a specified agent A to new location X-Y and update graphics
% loc_constraint/4 check that
loc_constraint(L, L, W, F):-
	L > F,
	L < (W-F).
loc_constraint(L, LN, W, F):-
	L > F,
	LN is W-F.
loc_constraint(L, LN, W, F):-
	L < (W-F),
	LN is F+1.

% avoid_border/5
avoid_border(Agt, X, Y, X, Y):-
	display(_, W, H),
	agent_atts(Agt, _, F, _, _, _),
	loc_constraint(X, X, W, F),
	loc_constraint(Y, Y, H, F).
avoid_border(Agt, X, Y, X, YNew):-
	display(_, W, H),
	agent_atts(Agt, _, F, Vx, Vy, _),
	loc_constraint(X, X, W, F),
	retract(agent_atts(Agt, S, F, Vx, Vy, Attach)), !,
	VNy is -Vy,
	assert(agent_attributes(Agt, S, F, Vx, VNy, Attach)),
	loc_constraint(Y, YNew, H, F).
avoid_border(Agt, X, Y, XNew, Y):-
	display(_, W, H),
	agent_atts(Agt, _, F, Vx, Vy, _),
	loc_constraint(Y, Y, W, F),
	retract(agent_atts(Agt, S, F, Vx, Vy, Attach)), !,
	VNx is -Vx,
	assert(agent_atts(Agt, S, F, VNx, Vy, Attach)),
	loc_constraint(X, XNew, H, F).
avoid_border(Agt, X, Y, XNew, YNew):-
	display(_, W, H),
	retract(agent_atts(Agt, S, F, Vx, Vy, Attach) ), !,
	VNx is -Vx,
	VNy is -Vy,
	assert(agent_atts(Agt, S, F, VNx, VNy, Attach)),
	loc_constraint(X, XNew, W, F),
	loc_constraint(Y, YNew, H, F).

% manipulate_coord/4
manipulate_coord(F, XorY, Axory, XorY):-
	Diff is abs(Axory-XorY),
	Diff > F.
manipulate_coord(F, XorY, Axory, New):-
	XorY > Axory,
	New is Axory+F.
manipulate_coord(F, _, Axory, New):-
	New is Axory-F.

% avoid_collisions/6
avoid_collisions([], _V, X, Y, X, Y).
avoid_collisions([Agt|Rest], A, X1, Y1, X, Y):-
	agent_atts(A, _V1, F, _V2, _V3, _V4),
	not(close_to_agent(Agt, X1, Y1, F)),
	avoid_collisions(Rest, A, X1, Y1, X, Y).
avoid_collisions([Agt|Rest], A, X1, Y1, X, Y):-
	agent(Agt, Xagt, Yagt, _V1),
	agent_atts(A, _V2, F, _V3, _V4, _V5),
	manipulate_coord(F, X1, Xagt, Xt),
	manipulate_coord(F, Y1, Yagt, Yt),
	avoid_collisions(Rest, A, Xt, Yt, X, Y).

% move_agent/3
% Messy - does graphics in prolog require new ID for new circle?
moveagent(A, Xt, Yt):-
	collect_agents(Agts),
	delete(Agts, A, Temp),
	avoid_collisions(Temp, A, Xt, Yt, X1, Y1),
	avoid_border(A, X1, Y1, X, Y),
	retract(agent(A, _V1, _V2, D)), !,
	retract(agent_nature(A, GIdOld, Nature)),
	send(GIdOld, destroy),
	display(P, _V3, _V4),
	send(P, display, new(GId, circle(D)), point(X, Y)),
	send(GId, fill_pattern, colour(yellow)),
	assert(agent(A, X, Y, D)),
	assert(agent_nature(A, GId, Nature)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simple Flocking Behaviour Using Existing Synthetic1 Agents
% Reynolds boids are simulated birds.
% Typically their environment
%	consists of a number of obstacles that block their path.
% The boids are programmed with simple instructions
%	(1) maintain a minimum distance from obstacles and other boids.
%	(2) to match it's speed with the average speed of nearby boids.
%	(3) to fly toward the perceived centre of
%			the mass of the boids it can see.
% From these simple instructions, realistic flocking behaviour emerges.

% agent_mass_cofg/6
% What is the effect of including own X-Y in CofG?
% agent_mass_cofg([], X, Y, _v1, X, Y).
% Default is for agent not to sense  itself
agent_mass_cofg([], _V1, _V2, _V3, 0, 0).
% If can sense an agent then
agent_mass_cofg([Agt|Rest], X, Y, SenseD, CofX, CofY):-
	close_to_agent(Agt, X, Y, SenseD),
	agent_mass_cofg(Rest, X, Y, SenseD, CX, CY),
	agent(Agt, Xagt, Yagt, _Var),
	CofX is CX+Xagt,
	CofY is CY+Yagt.
% And if it cannot sense an agent
agent_mass_cofg([_Var|Rest], X, Y, SenseD, CX, CY):-
	agent_mass_cofg(Rest, X, Y, SenseD, CX, CY).

% Calculate sum velocity of agents that can be sensed
% agent_velocities/6
agent_velocities([],_,_,_,0,0).
agent_velocities([Agt|Rest], X, Y, SenseD, MVelx, MVely):-
	close_to_agent(Agt, X, Y, SenseD),
	agent_velocities(Rest, X, Y, SenseD, MVx, MVy),
	agent_atts(Agt, _V1, _V2, Velx,Vely, _V3),
	MVelx is MVx+Velx,
	MVely is MVy+Vely.
agent_velocities([_Var1|Rest], X, Y, SenseD, MVx, MVy):-
	agent_velocities(Rest, X, Y, SenseD, MVx, MVy).

% Behaviour for one synthetic reflexive agent in flocking mode
% agent_flock/2
agent_flock(Agts, Agt):-
	agent(Agt, X, Y, _Var1),
	agent_nature(Agt, _Var2, reflexive),
	retract(agent_atts(Agt, SenseD, MinD, Velx, Vely, Attach)),  !,
	delete(Agts, Agt, Temp),
	length(Agts,N),
	agent_mass_cofg(Temp, X, Y, SenseD, CX, CY),
	agent_velocities(Temp, X, Y, SenseD, MassVelx, MassVely),
	NewVelx is ( ((MassVelx/(N-1)) + 2*Velx)/3 ),
	NewVely is ( ((MassVely/(N-1)) + 2*Vely)/3 ),
	CofX is CX/N,
	CofY is CY/N,
	assert(agent_atts(Agt, SenseD, MinD, NewVelx, NewVely,Attach)),
	calculate_position(Agt, NtX, NtY),
	NX is NtX+(CofX-NtX)/10,
	NY is NtY+(CofY-NtY)/10,
	moveagent(Agt, NX, NY).
agent_flock(_Var1, Agt):-
	not(agent_nature(Agt, _Var2, reflexive)),
	write('Non-reflexive agents do not flock like this'), nl.

% Flock all agents over one cycle
% flock/2
flock(_Var, []).
flock(Agts, [Agt|Rest]):-
	agent_flock(Agts, Agt),
	flock(Agts, Rest).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eof
